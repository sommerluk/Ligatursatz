﻿//DESCRIPTION:Deutscher Ligatursatz für InDesign
// *****************************************************************************

// TODO Could I use fastEntireScript? Is it worth the pain?

/**
 * This script file basically starts the script file program_indesign.js.
 * This is useful, because this way we can set certain options. For example,
 * this is the only way to make that the script actions have one single
 * undo entry and therefor can be undone easily by the user.
 * @module Ligatursatz.js
 */

/* Some global declarations that are provided automatically by ExtendScript */
/*global
    app,
    File,
    ScriptLanguage,
    UndoModes
*/

// Get access to the script that we will call... 
var myFile = new File(
    app.activeScript.parent.fsName + "/Ligatursatz/program_indesign.js"
);

/* The statmenet <code>app.scriptPreferences.enableRedraw = false;</code> makes
 * the script execution faster. But it is reported also to cause problems with
 * progressbars on some platforms. Therefore commented out here. */
// app.scriptPreferences.enableRedraw = false;
app.doScript(
    // the script that will be executed
    myFile,
    // the language of the script
    ScriptLanguage.javascript,
    // arguments that are passed to the script (we do not pass arguments here)
    [],
    /* The undo mode. Determines wether the user can undo
     * all actions of this script with only 1 undo step or not.
     * UndoModes.SCRIPT_REQUEST let the user undo each single
     * operation of the script by its own undo script (= if the script
     * inserts 5 ZWNJ characters, you have to click 5 times on
     * "Undo" to get the previous state). "entireScript" and
     * "fastScript" however execute the hole script as only one undo
     * step (= if the script inserts 5 ZWNJ characters, you have to click
     * only 1 time on "Undo" to get the previous state).
     * "entireScript" seems to be quite save.
     * "fastEntireScript" seems to be faster, but has more pitfalls.
     * If you use "fastEntireScript", you may not have any "try" blocks
     * within your script. Furthermore, it triggers a bug on some
     * Indesign versions. A workaround for the bug is a nested doScript call:
     *
     *  app.doScript(
            "app.doScript(myRoutine, undefined, undefined, " +
                    "UndoModes.fastEntireScript);",
            undefined,
            undefined,
            UndoModes.entireScript
        );
     *
     * This is a workaround only for the bug. You still cannot use
     * "try" blocks within your script.
     */
    UndoModes.entireScript,
    // text string for the "undo" history of Indesign
    "Ligatursatz"
);
