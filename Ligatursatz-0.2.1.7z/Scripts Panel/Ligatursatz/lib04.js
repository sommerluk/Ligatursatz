// *****************************************************************************
// Pattern library: patlib

/**
 * This statement makes a pattern library available. This is the same pattern
 * system as in Tex/Latex. It processes patterns with the algorithm described
 * by Franklin Liangs thesis that is available at
 * www.tug.org/docs/liang/liang-thesis.pdf for download.
 * Bram Stein has written the JavaScript implementation that is available
 * at https://github.com/bramstein/hypher for download. Here comes a
 * simplified version of Bram Steins implementation.
 *
 * Copyright (c) 2011, Bram Stein
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * @class NS.patlib
 */

(function (namespace) {
    var trie,
        leftMin,
        rightMin;

    leftMin = 1;
    rightMin = 1;

    /**
     * Creates a trie from a language pattern.
     * @method createTrie
     * @private
     * @param patternArray {Object} An object with language patterns.
     * @return {Object} An object trie.
     */
    function createTrie(patternArray) {
        var size = 0,
            i = 0,
            c = 0,
            p = 0,
            chars = null,
            points = null,
            codePoint = null,
            t = null,
            tree = {
                internalPoints: []
            },
            patterns;

        for (size = 0; size < patternArray.length; size += 1) {
            if (!NS.utilities.isNonvalue(patternArray[size])) {
                patterns = patternArray[size].match(
                    new RegExp('.{1,' + (+size) + '}', 'g')
                );

                for (i = 0; i < patterns.length; i += 1) {
                    chars = patterns[i].replace(/[0-9]/g, '').split('');
                    points = patterns[i].split(/\D/);
                    t = tree;

                    for (c = 0; c < chars.length; c += 1) {
                        codePoint = chars[c].charCodeAt(0);

                        if (!t[codePoint]) {
                            t[codePoint] = {};
                        }
                        t = t[codePoint];
                    }

                    t.internalPoints = [];

                    for (p = 0; p < points.length; p += 1) {
                        t.internalPoints[p] = points[p] || 0;
                    }
                }
            }
        }
        return tree;
    }

    /**
     * This function tries to guess the ligature setting of an arbitrary
     * word. When called the first time, it will initialize the pattern
     * in memory, what will take a time. The next call will be much faster ...
     * @method applyPattern
     * @param word The word for pattern ligature setting.
     * @return {Array} The parts of the word, separated where a ZWNJ
     * should go.
     */
    namespace.applyPattern = function (word) {
        var characters,
            characterPoints = [],
            originalCharacters,
            i,
            j,
            k,
            node,
            points = [],
            wordLength,
            nodePoints,
            nodePointsLength,
            m = Math.max,
            result = [''];

        if (NS.utilities.isNonvalue(trie)) {
            trie = createTrie(NS.ligpattern.patterns);
        }

        word = '_' + word + '_';

        characters = word.toLowerCase().split('');
        originalCharacters = word.split('');
        wordLength = characters.length;

        for (i = 0; i < wordLength; i += 1) {
            points[i] = 0;
            characterPoints[i] = characters[i].charCodeAt(0);
        }

        for (i = 0; i < wordLength; i += 1) {
            node = trie;
            for (j = i; j < wordLength; j += 1) {
                node = node[characterPoints[j]];

                if (node) {
                    nodePoints = node.internalPoints;
                    if (nodePoints) {
                        nodePointsLength = nodePoints.length;
                        for (
                            k = 0;
                            k < nodePointsLength;
                            k += 1
                        ) {
                            points[i + k] = m(points[i + k], nodePoints[k]);
                        }
                    }
                } else {
                    break;
                }
            }
        }

        for (i = 1; i < wordLength - 1; i += 1) {
            if (i > leftMin &&
                    i < (wordLength - rightMin) &&
                    points[i] % 2) {
                result.push(originalCharacters[i]);
            } else {
                result[result.length - 1] += originalCharacters[i];
            }
        }

        return result;
    };

}(NS.getNamespaceObject("patlib"))); // available at this namespace
