﻿// *****************************************************************************
// (c) 2015 Lukas Sommer
//
// You can use this code - at your option - under the MIT license or the CC0.

// *****************************************************************************
// declarations for quality checking tools

/* Well known quality checking tools include jslint.com, hslint.com and eslint.
 * Their warning messages are terribly cryptic. jslinterrors.com provides
 * a human-readable description of the errors of jslint, hslint and eslint. */

/*jslint
    maxlen: 80
*/

// temporary jslint directives only during development process
/*jslint
    devel: true
    stupid: true
    todo: true
*/

// permament jslint directives
/*jslint
    node: true
    regexp: true
*/

// global declarations of Node.js
/*global
    require,
    Buffer
*/

// global declarations of ExtendScript
/*global
    NS,
    app,
    $,
    Window,
    localize,
    NothingEnum,
    File
*/

"use strict";

/**
 * @module Ligatursatz
 */

// *****************************************************************************
// TODO before release

/* our big TODO list with checks that have to be done before a release:
 * TODO remove "devel" directive from jslint options
 * TODO This file should be saved with BOM to permit the JavaScript engine to
 *      determine the encoding.
 * TODO This file should only contain ASCII characters (so also no BOM) ->
 *      Make a unittest for this.
 * TODO We can avoid try..catch by checking the number of open documents before.
 * TODO Review all the existing code documentation content
 * TODO remove the "devel" option of JSLint
 */

/**
 * We need namespaces, because we have a lot of code and we have to order it.
 * This is the global parent object for everything that is organized in
 * namespaces. The namespaces are the properties of this object.
 * @class NS
 */
var NS = {};

/**
 * Preconditions: myString contains the namespace identifier. You may use
 * only characters from a to z (both upper and lower case) to identify the
 * layers. Layer names may not be empty. Layer names are separated with
 * the full stop character. The corresponding namespace may not be
 * a non-object value.
 * @method NS.getNamespaceObject
 * @param myString {String}
 * @return {Object} If the namespace object "myString" exists, it is
 * returned. If it does not exist, it is created and the newly created
 * object is returned.
 */
NS.getNamespaceObject = function (myString) {
    var parts = myString.split("."),
        parent = NS,
        currentPart = "",
        i;

    if (!(/^[a-zA-Z]+(\.[a-zA-Z]+)*$/).test(myString)) {
        throw new Error("Invalid namespace requested.");
    }

    for (i = 0; i < parts.length; i += 1) {
        currentPart = parts[i];
        if (parent[currentPart] === undefined ||
                parent[currentPart] === null) {
            parent[currentPart] = {};
        } else {
            if ((typeof parent[currentPart]) !== "object" &&
                    (typeof parent[currentPart]) !== "function") {
                throw new Error("Namespace creating not possible due to " +
                        "collision with existing element.");
            }
        }
        parent = parent[currentPart];
    }

    return parent;
};

// *****************************************************************************
// Value library: utilities

/**
 * The NS.utilities library provides some utilities for every-day tasks,
 * especially (but not exclusivly) related to the ECMAScript data types.
 *
 * ECMAScripts type system seems to have more pitfalls than features. Example:
 * <code>NaN === NaN</code> evaluates to <code>false</code> and many others.
 * This is annoying and causes bugs. Solution: Do not deal directly with
 * ECMAScripts type system anymore, but use this library instead. You do not
 * have to remember the particularities of the typesystem and your code will
 * be easier to read. This library provides these categories:
 *
 * <ul>
 * <li>__isBoolean()__ Boolean.</li>
 * <li>__isNonvalue()__ `undefined` and `null`.</li>
 * <li>__isNumber()__ A number. Is always one of these sub-categories:
 * isNanNumber(), isPositiveInfinityNumber(), isNegativeInfinityNumber(),
 * isFiniteNumber(). The last one, isFiniteNumber(), can be 
 * any normal (positive, zero or negative), non-error finite
 * number. isIntegerFiniteNumber() is a sub-category of isFiniteNumber().
 * </li>
 * <li>__isString()__ String.</li>
 * <li>__isObject()__ An object. Can also be one of these sub-categories:
 * isArrayObject(), isFunctionObject(), isErrorObject(), isRegexpObject(),
 * isDateObject().</li>
 * <li>__engine created non-ECMAScript types__ are not covered by this
 * library.</li>
 * </ul>
 * @class NS.utilities
 */
(function (namespace) {
    /**
     * Preconditions: none.
     * @method getGreaterValue
     * @param firstValue {any}
     * @param secondValue {any}
     * @return Compares firstValue and SecondValue and returns the
     * bigger one. If both have the same value, it returns one of them, but
     * it is undefined, which one.
     */
    namespace.getGreaterValue = function (firstValue, secondValue) {
        if (firstValue > secondValue) {
            return firstValue;
        }
        return secondValue;
    };

    /**
     * Preconditions: none
     * @method isBoolean
     * @param myValue {any}
     * @return {Boolean} Returns <code>true</code> if <code>myValue</code> is
     * <code>Boolean</code>. Otherwise  it returns
     * <code>false</code>. */
    namespace.isBoolean = function (myValue) {
        return ((typeof myValue) === "boolean");
    };

    /**
     * Preconditions: none
     * Note: In most cases, you should use isNonvalue instead of this function.
     * @method isNull
     * @private
     * @param myValue {any}
     * @return {Boolean} Returns <code>true</code> if <code>myValue</code> is
     * <code>null</code>. Otherwise  it returns
     * <code>false</code>. */
    function isNull(myValue) {
        return (myValue === null);
    }

    /**
     * Preconditions: none
     * Note: In most cases, you should use isNonvalue instead of this function.
     *
     * Note: This function does not work around the problem that older
     * ECMAScript versions allowed to redefine `undefined`. If somebody does,
     * you probably have more problems in other parts of your code where
     * you do things like `var test = undefinded;`, so it is not worth
     * the pain to work around this problem.
     * @method isUndefined
     * @private
     * @param myValue {any}
     * @return {Boolean} Returns <code>true</code> if <code>myValue</code> is
     * <code>undefined</code>. Otherwise  it returns
     * <code>false</code>. */
    function isUndefined(myValue) {
        return (myValue === undefined);
        /* The value of undefined can be changed by the program because
         * undefined is not a reserved keyword. It would however be a
         * bad idea to do so. We could make our function safter by not
         * checking (myElement === undefined), but instead checking
         * (myElement === (void 0), which is the internal representation
         * of undefined and which will always give us correct results.
         * (Starting with ECMAScript 5 it is not possible to change
         * undefined anymore.) */
    }

    /**
     * Preconditions: none
     *
     * Note: This function does not work around the problem that older
     * ECMAScript versions allowed to redefine `undefined`. If somebody does,
     * you probably have more problems in other parts of your code where
     * you do things like `var test = undefinded;`, so it is not worth
     * the pain to work around this problem.
     * @method isNonvalue
     * @param myElement {any}
     * @return {Boolean} Returns <code>true</code> if <code>myValue</code> is
     * <code>undefined</code> or <code>null</code>. Otherwise  it returns
     * <code>false</code>. This function is just a small utility
     * for dealing with the confusing fact that ECMAScript knows two
     * values for non-values, and not only one value like most other programming
     * languages do. */
    namespace.isNonvalue = function (myValue) {
        // check if myElement is null or undefined
        return (isNull(myValue) || isUndefined(myValue));
        /* The value of undefined can be changed by the program because
         * undefined is not a reserved keyword. It would however be a
         * bad idea to do so. We could make our function safter by not
         * checking (myElement === undefined), but instead checking
         * (myElement === (void 0), which is the internal representation
         * of undefined and which will always give us correct results.
         * (Starting with ECMAScript 5 it is not possible to change
         * undefined anymore.) */
    };

    /**
     * Preconditions: none
     * @method isObject
     * @param myVariable {Any}
     * @return {Boolean} <code>true</code> if myVariable is an object. (Note
     * that e.g. functions are also objects in ECMAScript.) Otherwise it
     * returns <code>false</code>. */
    namespace.isObject = function (myVariable) {
        /* In ECMAScript, null has type "object". This is a bug in
         * ECMAScript. We have to work around this, because obviously
         * we do not treat null as an object. */
        return ((myVariable !== null) &&
                ((typeof myVariable) === "object" ||
                (typeof myVariable) === "function"));
    };

    /**
     * Preconditions: none
     * @method isString
     * @param myVariable {Any}
     * @return {Boolean} <code>true</code> if myVariable is a
     * string type.
     * Otherwise it returns <code>false</code>. */
    namespace.isString = function (myVariable) {
        return ((typeof myVariable) === "string");
    };

    /**
     * Preconditions: none
     * @method isNumber
     * @param myVariable {Any}
     * @return {Boolean} <code>true</code> if myVariable is a
     * number type.
     * Otherwise it returns <code>false</code>. */
    namespace.isNumber = function (myVariable) {
        return (typeof myVariable) === "number";
    };

    /**
     * Preconditions: none
     * In ECMAScript, comparing like <code>myVariable === NaN</code> does
     * not work, because ECMAScript treats NaN as unequal (!) to itself.
     * Also the build-in isNaN() function does not work reliably because
     * it converts non-number types.
     * You can use this function instead, which is a better and simpler way
     * to check it.
     * @method isNanNumber
     * @param myVariable {Any}
     * @return {Boolean} <code>true</code> if myVariable has
     * the value <code>NaN</code>.
     * Otherwise it returns <code>false</code>. */
    namespace.isNanNumber = function (myVariable) {
        /* The global function isNaN() works fine if the argument if a number.
         * But if it is not a number, it is first converted to a number. So
         * you can get a NaN value though myVariable is not a number. We
         * work around this problem by checking both: if myVariable is of
         * type number, and if its value is NaN. */
        return Boolean(namespace.isNumber(myVariable) && isNaN(myVariable));
    };

    /**
     * Preconditions: none
     * In ECMAScript, there are some special number values. Among others,
     * you have positive infinity (result of e.g. 3/0) and negative
     * infinity (result of e.g. -3/0). This function helps checking this.
     * @method isPositiveInfinityNumber
     * @param myValue {Any}
     * @return {Boolean} <code>true</code> if myValue has
     * the value <code>Infinity</code>.
     * Otherwise it returns <code>false</code>. */
    namespace.isPositiveInfinityNumber = function (myValue) {
        /* It is okay to not check the type of myValue before comparing,
         * because the type coercetion never converts values to Infinity. */
        return (myValue === Infinity);
    };

    /**
     * Preconditions: none
     * In ECMAScript, there are some special number values. Among others,
     * you have positive infinity (result of e.g. 3/0) and negative
     * infinity (result of e.g. -3/0). This function helps checking this.
     * @method isNegativeInfinityNumber
     * @param myValue {Any}
     * @return {Boolean} <code>true</code> if myValue has
     * the value <code>-Infinity</code>.
     * Otherwise it returns <code>false</code>. */
    namespace.isNegativeInfinityNumber = function (myValue) {
        /* It is okay to not check the type of myValue before comparing,
         * because the type coercetion never converts values to Infinity. */
        return (myValue === -Infinity);
    };

    /**
     * Preconditions: none
     * In ECMAScript, there are some special number values: -Infinity,
     * Infinity and NaN. All other number values are normal values.
     * They are called "finite" number values. Use this function instead
     * of the build-in isFinite() to test if a value is a number type
     * and has a finite number value. As distinct from the build-in
     * isFinite(), this function prevents type coercetion and returns false
     * for isFiniteNumber("5").
     * @method isFiniteNumber
     * @param myValue {Any}
     * @return {Boolean} <code>true</code> if myValue is a non-special
     * number value. Otherwise it returns <code>false</code>. */
    namespace.isFiniteNumber = function (myValue) {
        return (namespace.isNumber(myValue) && isFinite(myValue));
    };

    /**
     * Preconditions: none
     * @method isIntegerFiniteNumber
     * @param myValue {Any}
     * @return {Boolean} <code>true</code> if myValue is a finite number
     * value without decimals. Otherwise it returns <code>false</code>. */
    namespace.isIntegerFiniteNumber = function (myValue) {
        if (namespace.isFiniteNumber(myValue)) {
            if ((myValue % 1) === 0) {
                return true;
            }
        }
        return false;
    };

    /*
     * Preconditions: none
     * In ECMAScript, the value 0 can be positive or negative. Normally, you
     * can ignore this, because -0 === 0 is true. Use this function
     * if you want to determine the sign.
     * @method isPositiveZero
     * @param myValue {Any}
     * @return {Boolean} <code>true</code> if myValue is a positive 0.
     * Otherwise it returns <code>false</code>.
     */
    /*
    namespace.isPositiveZero = function (myValue) {
        return Boolean(
            myValue === 0 && ((1 / myValue) > 0)
        );
    };
    */

    /*
     * Preconditions: none
     * In ECMAScript, the value 0 can be positive or negative. Normally, you
     * can ignore this, because -0 === 0 is true. Use this function
     * if you want to determine the sign.
     * @method isNegativeZero
     * @param myValue {Any}
     * @return {Boolean} <code>true</code> if myValue is a negative 0.
     * Otherwise it returns <code>false</code>.
     */
    /*
    namespace.isNegativeZero = function (myValue) {
        return Boolean(
            myValue === 0 && ((1 / myValue) < 0)
        );
    };
    */

    /**
     * Preconditions: none
     * Returns a string with informations about the first argument of
     * this function. It is always safe to call this function, even if
     * the first argument does not exist, is <code>undefined</code>,
     * <code>null</code> or <code>NaN</code>.
     * @method myDataIntrospection
     * @param myObject {Any}
     * @return {String} A string with some information about myObject
     */
    namespace.myDataIntrospection = function (myObject) {
        var myTypeof = (typeof myObject),
            myPrototype = Object.prototype.toString.call(myObject),
            myConstructorName,
            myCurrentEnumerableProperty,
            myEnumerableProperties = "";

        if (!NS.utilities.isNonvalue(myObject)) {
            myConstructorName = myObject.constructor.name;
            // Using for...in instead of Object.keys, because ExtendScript
            // does not support the latter.
            for (myCurrentEnumerableProperty in myObject) {
                myEnumerableProperties += myCurrentEnumerableProperty;
                myEnumerableProperties += " ";
            }
        }

        return (
            "ECMA: value:\n" +
                myObject +
                "\n\nECMA: typeof:\n" +
                myTypeof +
                "\n\nECMA: prototype:\n" +
                myPrototype +
                "\n\nECMA: construnctor name:\n" +
                myConstructorName +
                "\n\nECMA: enumerable properties:\n" +
                myEnumerableProperties +
                "\n"
        );
    };

    /**
     * Preconditions: none
     * It is always safe to call this function, even if myVariable is
     * <code>undefined</code> or <code>null</code>.
     * @method isRegexpObject
     * @param myValue
     * @return <code>true</code> is myValue is a regular expression value,
     * otherwise <code>false</code>.
     */
    namespace.isRegexpObject = function (myValue) {
        return (Object.prototype.toString.call(myValue) ===
                '[object RegExp]');
    };

    /**
     * Preconditions: none
     * @method isFunctionObject
     * @param myVariable {Any}
     * @return {Boolean} <code>true</code> if myVariable is a function. (Note
     * that functions are also objects in ECMAScript.) Otherwise it
     * returns <code>false</code>. */
    namespace.isFunctionObject = function (myVariable) {
        /* Normally, a typeof check should be enought to determine wether
         * a value is a function or not. But some old, buggy ECMAScript
         * implementations like Adobes ExtendScript return "function"
         * also for regular expressions. So we work around this bug here.
         */
        return (((typeof myVariable) === "function") &&
                !namespace.isRegexpObject(myVariable));
    };

    /**
     * Preconditions: none
     * It is always safe to call this function, even if myVariable is
     * <code>undefined</code> or <code>null</code>.
     *
     * This function does not work in ExtendScript (remember that Adobe
     * failed in doing a standard ECMAScript implementation). Use
     * NS.extendscript.isArrayObject instead when you are working in
     * ExtendScript.
     * @method isArrayObject
     * @param myVariable
     * @return <code>true</code> is myVariable is an array object,
     * otherwise <code>false</code>.
     */
    namespace.isArrayObject = function (myVariable) {
        /* Since ECMAScript 5, we have Array.isArray(), which is the most
         * reliable way to detect Arrays.
         *
         * if (namespace.isFunctionObject(Array.isArrayObject)) {
         *     return Boolean(Array.isArrayObject(myVariable));
         * }
         *
         * But as we cannot be sure that there are always ECMAScript 5 features,
         * it is better to search another solution.
         *
         * The preferred and only reliable way to check if a value is a
         * certain build-in object like Array is:
         *
         * Object.prototype.toString.call(myVariable) === "[object Array]"
         *
         * Other possiblities do not work reliable. Consider these
         * possibilities:
         *
         * myVariable instanceof Array;
         *
         * myVariable.constructor === Array;
         *
         * myVariable.constructor.name === "Array";
         *
         * myVariable.toString === "[object Array]"
         *
         * The first and the second one do not work in browers across
         * windows (because each window has its own environment and therefor
         * its own - and different - Array function). The third does not work
         * reliable because many implementations do not provide
         * .constructor.name at all or deliver unexpected results. Even when it
         * works, furthermore, there can be easily collisions with
         * user-defined constructor names. The fourth works not that bad, but
         * also .toString can be customized. So it is better to use the
         * standard Object.prototype.toString.call() way to make sure to get
         * the standard implementation. This should work reliable for all
         * correct implementations of ECMAScript (at least from ECMAScript 3).
         */
        return (Object.prototype.toString.call(myVariable) ===
                "[object Array]");
    };

    /**
     * Preconditions: none
     * It is always safe to call this function, even if myVariable is
     * <code>undefined</code> or <code>null</code>.
     * @method isDateObject
     * @param myValue
     * @return <code>true</code> is myValue is a Date value,
     * otherwise <code>false</code>.
     */
    namespace.isDateObject = function (myValue) {
        return (Object.prototype.toString.call(myValue) ===
                '[object Date]');
    };

    /**
     * Preconditions: none
     * It is always safe to call this function, even if myVariable is
     * <code>undefined</code> or <code>null</code>.
     * @method isErrorObject
     * @param myValue
     * @return <code>true</code> is myValue is a Date value,
     * otherwise <code>false</code>.
     */
    namespace.isErrorObject = function (myValue) {
        return (Object.prototype.toString.call(myValue) ===
                '[object Error]');
    };

    /**
     * Preconditions: none
     * Truncates everything after the decimal separator and returns the result.
     * -17 to -17;
     * -17.2 to -17;
     * -17.9 to -17;
     * 17 to -17;
     * 0.9 to 0;
     * 0.1 to 0;
     * -0.9 to 0;
     * -0.1 to 0
     * @method truncateToInteger
     * @param myNumber
     * @return {Number} If myNumber is a finite number, the integer part.
     * Otherwise `NaN`.
     */
    namespace.truncateToInteger = function (myNumber) {
        if (namespace.isFiniteNumber(myNumber)) {
            return myNumber - (myNumber % 1);
        }
        return NaN;
    };

}(NS.getNamespaceObject("utilities"))); // available at this namespace

// *****************************************************************************
// Algorithm library: algorithms

/**
 * This statement makes some algorithms available.
 * @class NS.algorithms
 */
(function (namespace) {

    /**
     * Helper function for indirect sorting. Imagine that the data that you
     * want to sort is very big. So each swap of data takes a lot of time.
     * So you want to reduce the amount of swap operations. Imagine that
     * you have data with the indixes 1...n. To do an indirect sorting,
     * you create an additional indexArray, that is initialized with
     * <code>indexArray[0] = 0;
     * indexArray[1] = 1;
     * indexArray[2] = 2;
     * ...
     * indexArray[n] = n;</code>
     * Now, in the sort algorithm you compare the real data, but you swap
     * only the data in your indexArray. So the sort algorithm will work
     * quite fast. After that, you still have to save your permutations.
     * You have two possiblities: First: You simply create a new data structure,
     * reading one by one the corresponding data from the old data structure.
     * That is simply, but during this process, you need the double memory
     * in RAM. Second, you can use this algorithm to do the permutation
     * "in situ". That means that the permutation is probably a little slower,
     * but it is done within the existing data structure, so you do (almost) not
     * need additional memory in RAM.
     * @method insituPermutation
     * @param valueArray The array with the original data.
     * @param indexArray The index array (the result of an indirect search
     * function)
     */
    namespace.insituPermutation = function (valueArray, indexArray) {
        var temp, // value type
            i,
            j,
            k;
        for (i = 0; i < valueArray.length; i += 1) {
            if (indexArray[i] !== i) {
                temp = valueArray[i];
                k = i;
                do {
                    j = k;
                    valueArray[j] = valueArray[indexArray[j]];
                    k = indexArray[j];
                    indexArray[j] = j;
                } while (k === i);
                valueArray[j] = temp;
            }
        }
    };

    function quicksort(
        leftmostElementIndex,
        rightmostElementIndex,
        valueAt,
        isFirstSmallerThanSecond,
        swap
    ) {
        var pivotElementValue,
            partitionElementIndex,
            middleElementIndex,
            i,
            a,
            b,
            c;

        // More than 1 element in the range? If so, we have some work to do.
        // Otherwise, we do nothing.
        if (leftmostElementIndex < rightmostElementIndex) {

            ////////////////////////////////////////////////////////////////
            // Determine the pivot, using the median-of-three rule:
            // We look at three values: The value at the left, the value at
            // the middle and the value at the right. We choose a median
            // value of these three values as pivot value and make sure (by
            // eventually swapping values) that this pivot value is at the
            // position rightmostElementIndex.
            //
            // Determining the median is harder than simply using the
            // rightmost element as pivot. However, the median solution
            // behaves much faster on data that is yet a little bit (or a
            // lot) pre-ordered.
            ////////////////////////////////////////////////////////////////
            /* The following line could also be much simpler:
             *
             * middleElementIndex = Math.round(
             *     (leftmostElementIndex + rightmostElementIndex) / 2
             * );
             *
             * But imagine that rightmostElementIndex has the biggest
             * possible (save) integer value. If we add leftmostElementIndex
             * now, we would have an integer overflow if we would program
             * in C++. As we program in ECMAScript we get an unsafe integer,
             * so probably we will fail silently. To avoid this, we use the
             * above, more complex way to get the middle element.
             */
            middleElementIndex = Math.round(
                leftmostElementIndex +
                        ((rightmostElementIndex - leftmostElementIndex) / 2)
            );

            // cache some values for multiple usage
            a = valueAt(leftmostElementIndex);
            b = valueAt(middleElementIndex);
            c = valueAt(rightmostElementIndex);

            // make sure that the median element within [a, b, c] is swapped
            // to the position c (rightmostElementIndex):
            if (isFirstSmallerThanSecond(b, a)) { // b < a
                if (isFirstSmallerThanSecond(c, b)) { // c < b
                    // We have b < a AND c < b, so
                    // we have c < b < a, so b is median.
                    swap(middleElementIndex, rightmostElementIndex);
                } else { // c >= b
                    if (!isFirstSmallerThanSecond(c, a)) { // c >= a
                        // We have b < a AND c >= b AND c >= a,
                        // so we have c >= a > b, so a is median.
                        swap(leftmostElementIndex, rightmostElementIndex);
                    } /* else: c < a
                       * We have b < a AND c >= b AND c < a,
                       * so we have a > c >= b, so c is median. -> nothing
                       * to do
                       */
                }
            } else { // b >= a
                if (isFirstSmallerThanSecond(c, a)) { // c < a
                    // We have b >= a AND c < a, so
                    // we have b >= a > c, so a is median.
                    swap(leftmostElementIndex, rightmostElementIndex);
                } else { // c >= a
                    if (!isFirstSmallerThanSecond(c, b)) { // c >= b
                        // We have b >= a AND c >= a AND c >= b,
                        // so we have c >= b >= a, so b is median.
                        swap(middleElementIndex, rightmostElementIndex);
                    } /* else: c < b
                       * We have b >= a AND c >= a AND c < b,
                       * so we have a <= c < b, so c is median. -> nothing
                       * to do
                       */
                }
            }

            ////////////////////////////////////////////////////////////////
            // Compare remaining array elements against pivotElementValue,
            // which is at rightmostElementIndex.
            ////////////////////////////////////////////////////////////////
            pivotElementValue = valueAt(rightmostElementIndex);
            partitionElementIndex = leftmostElementIndex;
            for (
                i = leftmostElementIndex;
                i < rightmostElementIndex;
                i += 1
            ) {
                if (isFirstSmallerThanSecond(valueAt(i),
                        pivotElementValue)) {
                    swap(i, partitionElementIndex);
                    partitionElementIndex += 1;
                }
            }

            ////////////////////////////////////////////////////////////////
            // Move pivot to its final place
            ////////////////////////////////////////////////////////////////
            swap(partitionElementIndex, rightmostElementIndex);

            ////////////////////////////////////////////////////////////////
            // We have now a partition element, and everything at the left
            // of it is smaller than itself, and everything at the right of
            // it is bigger than itself. Now, we use recursivly the same
            // system for the left and the right part.
            ////////////////////////////////////////////////////////////////
            quicksort(
                leftmostElementIndex,
                partitionElementIndex - 1,
                valueAt,
                isFirstSmallerThanSecond,
                swap
            );
            quicksort(
                partitionElementIndex + 1,
                rightmostElementIndex,
                valueAt,
                isFirstSmallerThanSecond,
                swap
            );
        }
    }

    function iterativeQuicksort(
        left,
        right,
        valueAt,
        isFirstSmallerThanSecond,
        swap
    ) {
        var pivotElementValue,
            partitionElementIndex,
            middleElementIndex,
            i,
            a,
            b,
            c,
            leftmostElementIndex,
            rightmostElementIndex,
            stack = [];

        /* Quicksort is a recursive algorithm. As we want to implement an
         * iterative version here, we use a variable with the name "stack".
         * There, we push always pairs (!) of indexes: First the left index,
         * second the right index of that what would be the next recursive
         * call if the algorithm where recursive.
         */
        stack.push(left);
        stack.push(right);
        while (stack.length > 0) {
            rightmostElementIndex = stack.pop();
            leftmostElementIndex = stack.pop();
            // More than 1 element in the range? If so, we have some work to do.
            // Otherwise, we do nothing.
            if (leftmostElementIndex < rightmostElementIndex) {

                ////////////////////////////////////////////////////////////////
                // Determine the pivot, using the median-of-three rule:
                // We look at three values: The value at the left, the value at
                // the middle and the value at the right. We choose a median
                // value of these three values as pivot value and make sure (by
                // eventually swapping values) that this pivot value is at the
                // position rightmostElementIndex.
                //
                // Determining the median is harder than simply using the
                // rightmost element as pivot. However, the median solution
                // behaves much faster on data that is yet a little bit (or a
                // lot) pre-ordered.
                ////////////////////////////////////////////////////////////////
                /* The following line could also be much simpler:
                 *
                 * middleElementIndex = Math.round(
                 *     (leftmostElementIndex + rightmostElementIndex) / 2
                 * );
                 *
                 * But imagine that rightmostElementIndex has the biggest
                 * possible (save) integer value. If we add leftmostElementIndex
                 * now, we would have an integer overflow if we would program
                 * in C++. As we program in ECMAScript we get an unsafe integer,
                 * so probably we will fail silently. To avoid this, we use the
                 * above, more complex way to get the middle element.
                 */
                middleElementIndex = Math.round(
                    leftmostElementIndex +
                            ((rightmostElementIndex - leftmostElementIndex) / 2)
                );

                // cache some values for multiple usage
                a = valueAt(leftmostElementIndex);
                b = valueAt(middleElementIndex);
                c = valueAt(rightmostElementIndex);

                // make sure that the median element within [a, b, c] is swapped
                // to the position c (rightmostElementIndex):
                if (isFirstSmallerThanSecond(b, a)) { // b < a
                    if (isFirstSmallerThanSecond(c, b)) { // c < b
                        // We have b < a AND c < b, so
                        // we have c < b < a, so b is median.
                        swap(middleElementIndex, rightmostElementIndex);
                    } else { // c >= b
                        if (!isFirstSmallerThanSecond(c, a)) { // c >= a
                            // We have b < a AND c >= b AND c >= a,
                            // so we have c >= a > b, so a is median.
                            swap(leftmostElementIndex, rightmostElementIndex);
                        } /* else: c < a
                           * We have b < a AND c >= b AND c < a,
                           * so we have a > c >= b, so c is median. -> nothing
                           * to do
                           */
                    }
                } else { // b >= a
                    if (isFirstSmallerThanSecond(c, a)) { // c < a
                        // We have b >= a AND c < a, so
                        // we have b >= a > c, so a is median.
                        swap(leftmostElementIndex, rightmostElementIndex);
                    } else { // c >= a
                        if (!isFirstSmallerThanSecond(c, b)) { // c >= b
                            // We have b >= a AND c >= a AND c >= b,
                            // so we have c >= b >= a, so b is median.
                            swap(middleElementIndex, rightmostElementIndex);
                        } /* else: c < b
                           * We have b >= a AND c >= a AND c < b,
                           * so we have a <= c < b, so c is median. -> nothing
                           * to do
                           */
                    }
                }

                ////////////////////////////////////////////////////////////////
                // Compare remaining array elements against pivotElementValue,
                // which is at rightmostElementIndex.
                ////////////////////////////////////////////////////////////////
                pivotElementValue = valueAt(rightmostElementIndex);
                partitionElementIndex = leftmostElementIndex;
                for (
                    i = leftmostElementIndex;
                    i < rightmostElementIndex;
                    i += 1
                ) {
                    if (isFirstSmallerThanSecond(valueAt(i),
                            pivotElementValue)) {
                        swap(i, partitionElementIndex);
                        partitionElementIndex += 1;
                    }
                }

                ////////////////////////////////////////////////////////////////
                // Move pivot to its final place
                ////////////////////////////////////////////////////////////////
                swap(partitionElementIndex, rightmostElementIndex);

                ////////////////////////////////////////////////////////////////
                // We have now a partition element, and everything at the left
                // of it is smaller than itself, and everything at the right of
                // it is bigger than itself. Now, we use recursivly the same
                // system for the left and the right part.
                ////////////////////////////////////////////////////////////////
                // at the left of partitionElement
                stack.push(leftmostElementIndex); // left element
                stack.push(partitionElementIndex - 1); // right element

                // at the right of partitionElement
                stack.push(partitionElementIndex + 1);
                stack.push(rightmostElementIndex);
            }
        }
    }

    /**
     * Creates a sort function. The algorithm is Quicksort. The algorithm
     * is not stable (that means, that elements that are equal are not
     * guaranteed preserve their order). The algorithm uses the median-of-three
     * system to calculate the pivot element. That means, that also on
     * pre-ordered data, the algorithm is not so slow. The algorithm is
     * implemented independent from the type of data storage. So you have
     * to provide some callbacks for data management. It must be a
     * random access data structure that works with integer indexes. The
     * function is recursive, so you can get a stack overflow because of
     * the recursion deepth. To avoid this, you can use
     * makeIterativeQuicksortFunction instead.
     * @method makeQuicksortFunction
     * @param valueAt {Function} A function. Arguments: index. Returns:
     * The value at position index.
     * @param isFirstSmallerThanSecond {Function} A function. Arguments:
     * firstValue, secondValue. Returns: true if first is smaller than second,
     * otherwise false.
     * @param swap {Function} A function. Arguments: firstIndex, secondIndex.
     * Swaps (interchanges) the data at the index positins firstIndex and
     * secondIndex.
     * @return {Function} A function. Arguments: firstIndex, lastIndex. Sorts
     * the data structure in the range from firstIndex (including) to
     * lastIndex (including).
     */
    namespace.makeQuicksortFunction = function (
        valueAt,
        isFirstSmallerThanSecond,
        swap
    ) {
        if (!NS.utilities.isFunctionObject(valueAt) ||
                !NS.utilities.isFunctionObject(isFirstSmallerThanSecond) ||
                !NS.utilities.isFunctionObject(swap)) {
            throw new Error("The initialization arguments must be functions.");
        }
        return function (firstIndex, lastIndex) {
            if (!NS.utilities.isNumber(firstIndex) ||
                    !NS.utilities.isNumber(lastIndex)) {
                throw new Error("The arguments must be numbers.");
            }
            quicksort(
                firstIndex,
                lastIndex,
                valueAt,
                isFirstSmallerThanSecond,
                swap
            );
        };
    };

    /**
     * Creates a sort function. The algorithm is Quicksort. The algorithm
     * is not stable (that means, that elements that are equal are not
     * guaranteed preserve their order). The algorithm uses the median-of-three
     * system to calculate the pivot element. That means, that also on
     * pre-ordered data, the algorithm is not so slow. The algorithm is
     * implemented independent from the type of data storage. So you have
     * to provide some callbacks for data management. It must be a
     * random access data structure that works with integer indexes. This
     * is an iterative version of quicksort that avoids stack overflows.
     * The normal recursive version is available with makeQuicksortFunction.
     * @method makeIterativeQuicksortFunction
     * @param valueAt {Function} A function. Arguments: index. Returns:
     * The value at position index.
     * @param isFirstSmallerThanSecond {Function} A function. Arguments:
     * firstValue, secondValue. Returns: true if first is smaller than second,
     * otherwise false.
     * @param swap {Function} A function. Arguments: firstIndex, secondIndex.
     * Swaps (interchanges) the data at the index positins firstIndex and
     * secondIndex.
     * @return {Function} A function. Arguments: firstIndex, lastIndex. Sorts
     * the data structure in the range from firstIndex (including) to
     * lastIndex (including).
     */
    namespace.makeIterativeQuicksortFunction = function (
        valueAt,
        isFirstSmallerThanSecond,
        swap
    ) {
        if (!NS.utilities.isFunctionObject(valueAt) ||
                !NS.utilities.isFunctionObject(isFirstSmallerThanSecond) ||
                !NS.utilities.isFunctionObject(swap)) {
            throw new Error("The initialization arguments must be functions.");
        }
        return function (firstIndex, lastIndex) {
            if (!NS.utilities.isNumber(firstIndex) ||
                    !NS.utilities.isNumber(lastIndex)) {
                throw new Error("The arguments must be numbers.");
            }
            iterativeQuicksort(
                firstIndex,
                lastIndex,
                valueAt,
                isFirstSmallerThanSecond,
                swap
            );
        };
    };

    /**
     * Creates a sort function. The algorithm is Quicksort. The algorithm
     * is not stable (that means, that elements that are equal are not
     * guaranteed preserve their order). The algorithm uses the median-of-three
     * system to calculate the pivot element. That means, that also on
     * pre-ordered data, the algorithm is not so slow. The algorithm is
     * implemented independent from the type of data storage. So you have
     * to provide some callbacks for data management. It must be a
     * random access data structure that works with integer indexes. The first
     * index must be 0.
     * @method makeIndirectIterativeQuicksortFunction
     * @param valueAt {Function} A function. Arguments: index. Returns:
     * The value at position index.
     * @param isFirstSmallerThanSecond {Function} A function. Arguments:
     * firstValue, secondValue. Returns: true if first is smaller than second,
     * otherwise false.
     * @param lastIndex {Function} A function. Arguments: none. Returns:
     * The index of the last element.
     * @return {Function} A function. Arguments: none. Sorts
     * the data structure from index 0 up to and including lastIndex() and
     * returns an array with index from 0 to lastIndex.
     */
    namespace.makeIndirectIterativeQuicksortFunction = function (
        valueAt,
        isFirstSmallerThanSecond,
        lastIndex
    ) {
        if (!NS.utilities.isFunctionObject(valueAt) ||
                !NS.utilities.isFunctionObject(isFirstSmallerThanSecond) ||
                !NS.utilities.isFunctionObject(lastIndex)) {
            throw new Error("The initialization arguments must be functions.");
        }

        return function () {
            var myReturnValue = [],
                i,
                myLastIndex = lastIndex();
            for (i = 0; i <= myLastIndex; i += 1) {
                myReturnValue[i] = i;
            }
            function internal_swap(firstIndex, secondIndex) {
                var temp;
                temp = myReturnValue[firstIndex];
                myReturnValue[firstIndex] = myReturnValue[secondIndex];
                myReturnValue[secondIndex] = temp;
            }

            function internal_valueAt(index) {
                return valueAt(myReturnValue[index]);
            }
            iterativeQuicksort(
                0,
                myLastIndex,
                internal_valueAt,
                isFirstSmallerThanSecond,
                internal_swap
            );
            return myReturnValue;
        };
    };

    /**
     * Creates a sort function. The algorithm is the algorithm provided
     * by Array.prototype.sort() of the ECMAScript engine. The algorithm
     * is not stable (that means, that elements that are equal are not
     * guaranteed preserve their order). As Array.prototype.sort() is
     * part of the engine, it is native code of the engine, so it is ofen
     * the fastest sort. This factory function is just a convenience
     * function to make Array.prototype.sort() also available for other
     * types of data storage than arrays.
     * implemented independent from the type of data storage. So you have
     * to provide some callbacks for data management. It must be a
     * random access data structure that works with integer indexes. The first
     * index must be 0.
     * @method makeIndirectNativesortFunction
     * @param compare {Function} A function. Arguments:
     * firstIndex, secondIndex. Returns: A number. Negative value if the value
     * at firstIndex is smaller than the value at secondIndex,
     * zero if both values are equal, or a positive value if the value at
     * firstIndcex is bigger than the value at secondIndex.
     * @param lastIndex {Function} A function. Arguments: none. Returns:
     * The index of the last element.
     * @return {Function} A function. Arguments: none. Sorts
     * the data structure from index 0 up to and including lastIndex() and
     * returns an array with index from 0 to lastIndex.
     */
    namespace.makeIndirectNativesortFunction = function (
        compare,
        lastIndex
    ) {
        if (!NS.utilities.isFunctionObject(compare) ||
                !NS.utilities.isFunctionObject(lastIndex)) {
            throw new Error("The initialization arguments must be functions.");
        }

        return function () {
            var myReturnValue = [],
                i,
                myLastIndex = lastIndex();
            for (i = 0; i <= myLastIndex; i += 1) {
                myReturnValue[i] = i;
            }
            myReturnValue.sort(compare);
            return myReturnValue;
        };
    };

}(NS.getNamespaceObject("algorithms"))); // available at this namespace

// *****************************************************************************
// String library: stringlib

/**
 * This statement makes some string utilities available.
 * @class NS.stringlib
 */
(function (namespace) {

    /**
     * @method codepointIndexToCodeunitIndex
     * @param myString {String}
     * @param myCodepointIndex {Number}
     * @return Returns the codeunit index of the codepoint at
     * position myCodepointIndex. If this is a codepoint
     * within the BMP, you get the codeunit index of
     * this codeunit. If it is a codepoit outside the BMP,
     * you get the codeunit index of the high surrogat. If
     * myCodepointIndex is negative, then it counts from
     * the rear of the text (-1 is the last codepoint,
     * -2 the one before the last codepoint ...). If
     * myCodepointIndex is not a valid index, this function
     * will return undefined.
     */
    namespace.codepointIndexToCodeunitIndex = function (
        myString,
        myCodepointIndex
    ) {
        var internalString,
            myCodepointCount,
            myPositiveCodepointIndex,
            codepointCounter,
            codeunitCounter;

        internalString = String(myString);
        myCodepointCount = namespace.countCodepoints(internalString);
        myPositiveCodepointIndex = Number(myCodepointIndex);
        if (myPositiveCodepointIndex < 0) {
            myPositiveCodepointIndex += myCodepointCount;
        }
        if (myPositiveCodepointIndex < 0) {
            return undefined;
        }

        codepointCounter = 0;
        codeunitCounter = 0;
        while (codepointCounter < myPositiveCodepointIndex &&
                codeunitCounter < internalString.length) {
            codepointCounter += 1;
            if (namespace.isSurrogate(internalString.charAt(codeunitCounter))) {
                codeunitCounter += 2;
            } else {
                codeunitCounter += 1;
            }
        }
        if (codeunitCounter >= internalString.length) {
            return undefined;
        }
        return codeunitCounter;
    };

    /**
     * @method isSurrogate
     * @param myCodeunit {String}
     * @return {Boolean} <code>true</code> if the first
     * codeunit of it is a surrogate (either high surrogate or low
     * surrogate); otherwise <code>false</code>. */
    namespace.isSurrogate = function (myCodeunit) {
        var myCodeunitValue = myCodeunit.charCodeAt(0);
        return ((55296 <= myCodeunitValue) && (myCodeunitValue <= 57343));
    };

    /**
     * @method myIsStringWithoutSurrogates
     * @param myVariable {Any}
     * @return {Boolean} <code>true</code> if myVariable is a primitive
     * string type that does not contain any surrogates. Otherwise
     * it returns <code>false</code>. */
    namespace.myIsStringWithoutSurrogates = function (myVariable) {
        var i;
        if (!NS.utilities.isString) {
            return false;
        }
        for (i = 0; i < myVariable.length; i += 1) {
            if (namespace.isSurrogate(myVariable.charAt(i))) {
                return false;
            }
        }
        return true;
    };

    /**
     * @method replace
     * @param myString {String}
     * @param myRemoveString {String}
     * @param myReplaceString {String}
     * @return {String} myString with all occurences of
     * myRemoveString substituted by myReplaceString. It works
     * without regular expressions, so you do not have to worry
     * about characters that are special characters in regular
     * expressions. */
    namespace.replace = function (myString, myRemoveString, myReplaceString) {
        /* .split will split String(myString) into an array of
         * strings. myRemoveString is the separator, so it will
         * not be within the array elements. .join will then
         * concat the array elements to one big string,
         * inserting myReplaceString between the elements. */
        return String(myString).split(myRemoveString).join(myReplaceString);
    };

    /**
     * @method remove
     * @param myString
     * @param firstIndex
     * @param lastIndex
     * @return myString with all codepoints from firstIndex
     * to lastIndex removed.
     */
    namespace.remove = function (myString, firstIndex, lastIndex) {
        var myReturnValue;
        myReturnValue = myString.slice(
            0,
            namespace.codepointIndexToCodeunitIndex(myString, firstIndex)
        );
        myReturnValue += myString.slice(
            namespace.codepointIndexToCodeunitIndex(myString, lastIndex + 1)
        );
        return myReturnValue;
    };

    /**
     * @method insert
     * @param myString
     * @param index
     * @param insertString
     * @return myString with insertString inserted after index. */
    namespace.insert = function (myString, index, insertString) {
        var myReturnValue,
            codeunitIndex = namespace.codepointIndexToCodeunitIndex(
                myString,
                index + 1
            );
        myReturnValue = myString.slice(0, codeunitIndex);
        myReturnValue += insertString;
        myReturnValue += myString.slice(codeunitIndex);
        return myReturnValue;
    };

    /**
     * Expects a string.
     * In JavaScript, a string is a sequenze of code _units_ of
     * an UTF-16 encoded text. For a valid UTF-16-encoded text,
     * this function it returns a number
     * which is the count of code _points_ in this string.
     * For an invalid UTF-16-encoded string, it returns a number
     * which is probably not the count of code points in this string.
     * @method countCodepoints
     * @param string
     */
    namespace.countCodepoints = function (string) {
        var myCodeunitCount = string.length,
            myCodepointCount = 0,
            i;
        for (i = 0; i < myCodeunitCount; i = i + 1) {
            if (namespace.isSurrogate(string.charAt(i))) {
                myCodepointCount = myCodepointCount + 0.5;
            } else {
                myCodepointCount = myCodepointCount + 1;
            }
        }
        return myCodepointCount;
    };

    /**
     * For a given string myCodeunits, this function returns
     * an array of strings. Each element of the array is of
     * type "string" and contains exactly one codepoint
     * @method toCodepointArray
     * @param myCodeunits
     */
    namespace.toCodepointArray = function (myCodeunits) {
        var i = 0,
            myReturnValue = [];
        while (i < myCodeunits.length) {
            if (namespace.isSurrogate(myCodeunits.charAt(i))) {
                myReturnValue.push(myCodeunits.slice(i, i + 2));
                i += 2;
            } else {
                myReturnValue.push(myCodeunits.charAt(i));
                i += 1;
            }
        }
        return myReturnValue;
    };

    /**
     * @method getCodepointAt
     * @return the codepoint at position codepointIndex of myString.
     */
    namespace.getCodepointAt = function (myString, codepointIndex) {
        // variable declarations
        var myCodeunitIndex,
            myCodepoint;

        // code
        myCodeunitIndex = namespace.codepointIndexToCodeunitIndex(
            myString,
            codepointIndex
        );
        if (!NS.utilities.isFiniteNumber(myCodeunitIndex)) {
            // This codepoint does not exist.
            return undefined;
        }
        // Calling String.charAt() works only reliable when the argument
        // is a valid codeunit index. Otherwise (other types, invalid indexes)
        // there will be unpredictable behaviour. As we have filtered
        // yet myCodeunitIndex, the following call should be save.
        myCodepoint = myString.charAt(myCodeunitIndex);
        if (namespace.isSurrogate(myCodepoint)) {
            myCodepoint += myString.charAt(myCodeunitIndex + 1);
        }
        return myCodepoint;
    };

    /**
     * @method fromScalarValue
     * @param myScalarValue {Number} The scalar value. An integer number
     * from 0x0 to 0xD7FF (decimal: 55295) or 0xE000 (decimal: 57344) to
     * 0x10FFFF (decimal 1114111).
     * @return {String} The corresponding valid and well-formed ECMAScript
     * string representation.
     */
    namespace.fromScalarValue = function (myScalarValue) {
        // variable declarations
        var temp,
            highSurrogate,
            lowSurrogate;

        // code
        if (!NS.utilities.isIntegerFiniteNumber(myScalarValue) ||
                ((myScalarValue > 0xD7FF) && (myScalarValue < 0xE000)) ||
                myScalarValue > 0x10FFFF ||
                myScalarValue < 0) {
            throw new Error("myScalarValue is not valid.");
        }

        // BMP codepoint?
        if (myScalarValue <= 0xFFFF) {
            return String.fromCharCode(myScalarValue);
        }

        // outside BMP -> calculate a surrogate pair

        temp = myScalarValue - 0x10000;

        highSurrogate = String.fromCharCode(
            NS.utilities.truncateToInteger(temp / 0x400) + 0xD800
        );
        lowSurrogate = String.fromCharCode(
            (temp % 0x400) + 0xDC00
        );

        return highSurrogate + lowSurrogate;
    };

    /**
     * ECMAScript source code allows Unicode escape sequenzes within strings.
     * Each of these represents one UTF16 codeunit. For example, a string that
     * contains the unicode character LATIN CAPITAL LETTER Z can be written
     * as "z" or as "\u005a" (always with exactly four hexadecimal digits).
     * This function converts integer numbers within the valid range
     * to their ECMAScript source code
     * representation. So for 0x5A it will return a string with exactly six
     * characters: The backslash, the LATIN SMALL LETTER U and the four
     * hexadecimal digits 0, 0, 5, a. It is not defined wether the digits
     * a, b, c, d, e, f are represented as uppercase or as lowercase.
     *
     * @method formatAsUnicodeEscape
     * @param codeunit {Number} The UTF16 codeunit as an integer in the range
     * from 0 to 65535
     */
    namespace.formatAsUnicodeEscape = function (codeunit) {
        var temp;
        if (!NS.utilities.isIntegerFiniteNumber(codeunit)) {
            throw new Error("codeunit should be a finite integer.");
        }
        if (codeunit < 0 || codeunit > 65535) {
            throw new Error("codeunit should be in rage from 0 to 65535");
        }
        temp = codeunit.toString(16);
        while (temp.length < 4) {
            temp = "0" + temp;
        }
        return ("\\u" + temp);
    };

}(NS.getNamespaceObject("stringlib"))); // available at this namespace
