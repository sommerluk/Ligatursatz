﻿#include "lib01.js"
#include "lib02.js"
#include "lib03.js"
#include "lib04.js"
#include "lib05.js"

NS.inligaturesetting.callLigatureSetting();