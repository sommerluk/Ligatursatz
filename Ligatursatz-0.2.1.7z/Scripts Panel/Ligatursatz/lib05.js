// *****************************************************************************
// (c) 2015 Lukas Sommer
//
// You can use this code - at your option - under the MIT license or the CC0.

// *****************************************************************************
// declarations for quality checking tools

/* Well known quality checking tools include jslint.com, hslint.com and eslint.
 * Their warning messages are terribly cryptic. jslinterrors.com provides
 * a human-readable description of the errors of jslint, hslint and eslint. */

/*jslint
    maxlen: 80
*/

// temporary jslint directives only during development process
/*jslint
    devel: true
    stupid: true
    todo: true
*/

// permament jslint directives
/*jslint
    node: true
    regexp: true
*/

// global declarations of Node.js
/*global
    require,
    Buffer
*/

// global declarations of ExtendScript
/*global
    NS,
    app,
    $,
    Window,
    localize,
    NothingEnum,
    File
*/

"use strict";

// *****************************************************************************
// Ligature library: liglib

/**
 * This statement makes some ligature setting utilities available.
 * <p>It works with rules. A rule is
 * expected to be composed by two parts:</p>
 * <p>1. the key: The key contains the word (all lowercase)
 *    without fancy things (no SOFT HYPHEN, no long
 *    s character, no whitespace, no interpunctuation).
 *    It should have at least one codepoint and may
 *    (theoretically) contain any character.</p>
 * <p>2. the value: the ligature setting: A sequenze of "0" and "1". For each
 *    codepoint in the key, we have exactly one character here:
 *    Either "0" if after this codepoint index in the key there
 *    shound not be a ZERO WIDTH NON-JOINER. Or "1" if after this
 *    codepoint index in the key there shound be a ZERO
 *    WIDTH NON-JOINER.</p>
 *
 * This library is designed to work with a wordlist from the Trennmuster
 * project, and with a pattern that was created from this list.
 *
 * Special case: Abreviations. There are words that have a different ligature
 * setting when they occure as abbreviations. Example: "Auf-lage" without
 * f-l-ligature. But as abbreviation "Aufl." it is written nevertheless
 * writtten with f-l-ligature. The point at the end of the abbreviation is
 * cut off by the unicode word boundary algorithm. But that is not a problem,
 * because the word list of the Trennmuster project contains the entry "Aufl"
 * without point. So, in general we do not have to worry about points after
 * abbreviations.
 *
 * Special case: Apostrophs. There are some few words like "Ku'damm" where the
 * apostroph really represents an inner part of a single word
 * ("Kurfuerstendamm").
 * However, mostly the apostroph represents a part of the word at the beginning
 * or at the end of single words ("Lauf ' weg!" instead of "Laufe weg.").
 * The unicode word boundary algorithm strips leading and tailing apostrophs,
 * (but no apostrophs in the middle of letters) and that is fine for us,
 * because "lauf" is part of the word list. So
 * a special treatment of apostrophs is not worth the pain.
 * @class NS.liglib
 */
(function (namespace) {
    var ignoreCodepointArray,
        isIgnoreCodepoint,
        removeIgnoreCodepoints,
        isZeroWidthNonJoiner,
        internal_makeWordInstructions,
        debugMode = true,
        canWordBeIgnored;

    /**
     * Some characters should be ignored in the lookup process because they are
     * not meaningfull for the lookup. SOFT HYPHEN is such a character.
     * This is an array of all codepoints that should be ignored. Each
     * element of the array is a string that contains one single codepoint.
     * This property is intented to be a constant value, so do not change it!
     * @property ignore
     * @type {Array}
     * @private
     */
    ignoreCodepointArray = [
        "\u00AD" // SOFT HYPHEN
    ];

    /**
     * Proconditions: none
     *
     * @method
     * @private
     * @return {Boolean} true if "codepoint" is an codepoint
     * in the ignore list. Otherwise returns false.
     */
    isIgnoreCodepoint = function (codepoint) {
        var myCodepoint = String(codepoint),
            i,
            found;

        // check preconditions
        if (debugMode) {
            if (NS.stringlib.countCodepoints(myCodepoint) !== 1) {
                throw new Error("Parameter " + myCodepoint +
                        " should contain exactly 1 codepoint, but instead " +
                        " it contains " +
                        NS.stringlib.countCodepoints(myCodepoint) +
                        " codepoints.");
            }
        }

        // code
        found = false;
        i = 0;
        while (found === false && i < ignoreCodepointArray.length) {
            if (ignoreCodepointArray[i] === myCodepoint) {
                found = true;
            }
            i += 1;
        }

        return found;
    };

    removeIgnoreCodepoints = function (myString) {
        var i,
            myReturnValue = myString;
        for (i = 0; i < ignoreCodepointArray.length; i += 1) {
            myReturnValue = NS.stringlib.replace(
                myReturnValue,
                ignoreCodepointArray[i],
                ""
            );
        }
        return myReturnValue;
    };

    isZeroWidthNonJoiner = function (myCodepoint) {
        return Boolean(myCodepoint === "\u200C");
    };

    /**
     * Creates a "unified" version of the string. This is
     * intented for lookup for keys. It substitutes
     * each codepoint with its corresponding lower-case
     * codepoint (if any). Exception: If the lower-case
     * correspondence is not also exactly one codepoint
     * (but, for example, two codepoints similar to
     * the correspondence of sharp s to SS) than the
     * upper-case codepoint is preserved. This function
     * uses the ECMAScript .toLowerCase function; that
     * means that surrogates remain always unchanged.
     * The substitution of the capital letter sharp s
     * with its lowercase counterpart is hardcoded
     * and works independent of the ECMAScript
     * interpreter. The lowercase letter latin long s
     * is substituted by the lowercase normal s.
     * @method unify
     * @param myString
     */
    namespace.unify = function (myString) {
        var myReturnValue = "",
            internalString = String(myString),
            i,
            myCharacter,
            myLowerCaseCharacter;
        internalString = internalString
            // replace capital letter sharp s with its lowercase counterpart
            // (This is not handeled well by .toLowerCase, so we do it
            // here manually)
            .replace(/\u1E9E/g, "\u00DF")
            // replace lowercase letter long s with lowercase letter "normal" s
            .replace(/\u017F/g, "s");
        /* We use String.toLowerCase to convert to lower case letters. For
         * surrogate codeunits, this function returns always the unchanged
         * argument itself. This is not correct following the unicode
         * standard and it is not perfect, but at least it does no harm here.
         */
        for (i = 0; i < internalString.length; i += 1) {
            myCharacter = internalString.charAt(i);
            myLowerCaseCharacter = myCharacter.toLowerCase();
            if (NS.stringlib.countCodepoints(myLowerCaseCharacter) === 1) {
                // If .toLowerCase() gives a single codepoint, use it
                myReturnValue += myLowerCaseCharacter;
            } else {
                // If .toLowerCase() gives more than one codepoint,
                // use the original codepoint instead.
                myReturnValue += myCharacter;
            }
        }
        return myReturnValue;
    };

    /**
     * Test if we can simply ignore this word. This can be pure numbers
     * like "134,4" or other situations where ligature setting is not useful,
     * like words with very few letters. As far as I know, there are no
     * german words with 3 or less letters that are composed of more than
     * one morphem. So ignoring these words seems reosonable. Furthermore,
     * the word list (Trennmusterprojekt) that we use, does not contain
     * words with 3 or less characters.
     * @method canWordBeIgnored
     * @param myWord {String}
     * @private
     * @return {Boolean} <code>true</code> if <code>myWord</code> can be
     * ignored, otherwise <code>false</code>.
     */
    canWordBeIgnored = (function () {
        var myReturnValue,
            myRegExp;
        // Test if we have at least 4 consecutive letters ...
        // TODO Das Wort "Fähre" würde ignoriert, falls das "ä" aus "a" und
        // einem kombinierenden Zeichen zusammengesetzt wurde.
        myRegExp = new RegExp(
            NS.wordboundary.getLetterRegExpString() +
                    NS.wordboundary.getLetterRegExpString() +
                    NS.wordboundary.getLetterRegExpString() +
                    NS.wordboundary.getLetterRegExpString()
        );
        myReturnValue = function (myWord) {
            return !myRegExp.test(
                removeIgnoreCodepoints(myWord)
            );
        };
        return myReturnValue;
    }());

    /**
     * Get instructions for doing the necessary changes
     * about ligature setting. This function accepts
     * a string with a word or a longer text with various
     * words.
     *
     * This function returns an object.
     *
     * This object has a property "statusCode" which can
     * have one of the following values:
     *
     * 1: The word is ignored. Example: Numbers like "123". The instruction
     *    array is empty.
     *
     * 2: The word was processed. It was found in the
     *    dictionary (respecting the rules). The
     *    instructions correspond to the dictionary.
     *
     * 3: The word was processed. It was not found in
     *    the dictionary (respecting the rules). The
     *    instructions are the result of a fancy algorithm
     *    that tries to guess them.
     *
     * The return value object has also a property
     * "instructionArray", which is an array of zero
     * or more instructions. Each instruction has these
     * properties:
     *
     * - index: A number. The index of this instruction. It indicates the
     *             affected code point.
     *             The first code point of myCodeunits has index 0,
     *             the second code point of myCodeunits has
     *             index 1 and so on...
     *             Note that we count code points, not code units!
     *
     * - action: A number. The action that has to be performed here.
     *           0 means that this code point is a
     *             zero-width-non-joiner that
     *             has to be deleted.
     *           1 means that after this code point a
     *             zero-width-non-joiner has
     *             to be inserted.
     *
     * The instructions in the array are ordered ascending
     * by their "index" value.
     * TODO DANGER Diese Funktion sollte ein definiertes Verhalten
     * haben, falls das Wort kein sauber abgetrenntes Wort
     * (wie vorgeschrieben in Unicode word wrap) ist.
     * @method internal_makeWordInstructions
     * @param myCodeunits {String} The string for which you want to
     * have instructions
     * @param myCallback {Function} Argument: A string. Returns: A rule
     * for this string.
     * @return The instructions.
     * @private
     */
    internal_makeWordInstructions = function (
        myCodeunits,
        myCallback
    ) {
        // Declare variables
        var myCodepointArray =
                    NS.stringlib.toCodepointArray(namespace.unify(myCodeunits)),
            mySearchString = "",
            mySearchStringCodepointCorrespondence = [],
            myInstructionArray = [],
            i,
            j,
            myLeftCharacterIndex,
            myRightCharacterIndex,
            myNonJoinerFound,
            myDictSearchResult;

        // Test if we can simply ignore this word ...
        if (canWordBeIgnored(myCodeunits)) {
            return {statusCode: 1, instructionArray: myInstructionArray};
        }
        // Initialization
        for (i = 0; i < myCodepointArray.length; i += 1) {
            if (!(isIgnoreCodepoint(myCodepointArray[i]) ||
                    isZeroWidthNonJoiner(myCodepointArray[i]))) {
                mySearchString += myCodepointArray[i];
                mySearchStringCodepointCorrespondence.push(i);
            }
        }

        // get a rule for this word
        myDictSearchResult = myCallback(mySearchString);

        // Determine the necessary instructions (based on
        // myDictSearchResult.lookupResult). We test only
        // the index positions _within_ the word, not at
        // the begin or at the end of the word.
        for (i = 0;
                // do not check after the last character, because this
                // script does not check non-joiners at word breaks.
                i < (myDictSearchResult.lookupResult.length - 1);
                i += 1) {
            myLeftCharacterIndex = mySearchStringCodepointCorrespondence[i];
            myRightCharacterIndex =
                    mySearchStringCodepointCorrespondence[i + 1];
            // If after myLeftCharacterIndex there should be a non-joiner...
            if (myDictSearchResult.lookupResult[i] === "1") {
                // Test if there is yet at least one ZERO WIDTH NON-JOINER
                // in the concerned range
                j = myLeftCharacterIndex + 1;
                myNonJoinerFound = false;
                while (!myNonJoinerFound && j < myRightCharacterIndex) {
                    if (myCodepointArray[j] === "\u200C") {
                        myNonJoinerFound = true;
                    }
                    j += 1;
                }
                // If there is not at least one ZERO WIDTH NON-JOINER in the
                // concerned range then we make an instruction for
                // inserting it.
                if (!myNonJoinerFound) {
                    myInstructionArray.push(
                        {index: myLeftCharacterIndex, action: 1}
                    );
                }
            // If after myLeftCharacterIndex should not be a non-joiner...
            } else {
                // In the concerned range there should be no ZERO WIDTH
                // NON-JOINER. We iterate over the hole range to
                // control this.
                for (
                    j = myLeftCharacterIndex + 1;
                    j < myRightCharacterIndex;
                    j += 1
                ) {
                    // For each ZERO WIDTH NON-JOINER in the concerned range
                    // we make an instruction for deleting it.
                    if (myCodepointArray[j] === "\u200C") {
                        myInstructionArray.push({index: j, action: 0});
                    }
                }
            }
        }

        // Return
        return {
            statusCode: myDictSearchResult.statusCode,
            instructionArray: myInstructionArray
        };
    };

    /**
     * @method makeIndividualWordInstruction
     * @param myCodeunits {String} The word for which you want to
     * have instructions
     * @param myRule {String} A rule for this word
     * @return ?
     */
    namespace.makeIndividualWordInstruction = function (
        myCodeunits,
        myEntry
    ) {
        var myCallback;

        myCallback = function () {
            return {lookupResult: myEntry, statusCode: 2};
        };

        return internal_makeWordInstructions(myCodeunits, myCallback);
    };

    /**
     * @method makeEntry
     * @param wordWithNonjoiners {String} A word that contains
     * ZERO WIDTH NON-JOINERs at the appropiate
     * places (or none of them if not appropriate). This function converts
     * the string to lowercase, so you do not have to worry about his.
     * @return {Array} At index 0 the key and at index 1 the value (the
     * rule for this key)
     */
    namespace.makeEntry = function (wordWithNonjoiners) {
        // declare variables
        var myUnifiedString = removeIgnoreCodepoints(
                namespace.unify(wordWithNonjoiners)
            ),
            myCodepointCount,
            myKey = "",
            myValue = "",
            i,
            myCodepoint;

        // create the content for the "entry string"
        myCodepointCount = NS.stringlib.countCodepoints(myUnifiedString);
        for (i = 0; i < myCodepointCount; i += 1) {
            myCodepoint = NS.stringlib.getCodepointAt(myUnifiedString, i);
            if (myCodepoint !== "\u200C") {
                myKey += myCodepoint;
                if (NS.stringlib.getCodepointAt(myUnifiedString, i + 1) ===
                        "\u200C") {
                    myValue += "1";
                } else {
                    myValue += "0";
                }
            }
        }

        // return myKey, a tabulator and myValue
        return [myKey, myValue];
    };

    /**
     * Helper function that applies ligature setting to a given word "myText"
     * (of type "string") using the instructions that it will obtain from
     * ligatureInstructions. Returns a string.
     * @method getStringWithAppliedInstructions
     * @param myText
     * @param ligatureInstructions
     */
    namespace.getStringWithAppliedInstructions = function (
        myText,
        ligatureInstructions
    ) {
        // Declare variables
        var myInstructionArray,
            i,
            myReturnValue;

        // initialize variables
        myReturnValue = myText;

        // Get the appropriate ligature setting instructions array
        myInstructionArray = ligatureInstructions.instructionArray;

        // Now parse our instruction list backwards.
        // If we would parse it forwards, we would change the index of the
        // instructions that still have not been applied. This would lead to
        // wrong results.
        for (i = myInstructionArray.length - 1; i >= 0; i -= 1) {
            if (myInstructionArray[i].action === 0) {
                // delete this character
                myReturnValue = NS.stringlib.remove(
                    myReturnValue,
                    myInstructionArray[i].index,
                    myInstructionArray[i].index
                );
            } else {
                // insert a ZERO WIDTH NON-JOINER \u200C after this character
                myReturnValue = NS.stringlib.insert(
                    myReturnValue,
                    myInstructionArray[i].index,
                    "\u200C"
                );
            }
        }
        return myReturnValue;
    };

    /**
     * A factory for ligature processor objects.
     * @method makeLigatureProcessor
     * @param userDictionarySearch {Function or Undefined or Null}
     * An object that represents this dictionary, or undefined.
     * @param wordDictionarySearch {Function or Undefined or Null}
     * An object that represents this dictionary, or undefined.
     * @param abCompoundDictionarySearch {Function or Undefined or Null}
     * An object that represents this dictionary, or undefined.
     * @param cCompoundDictionarySearch {Function or Undefined or Null}
     * An object that represents this dictionary, or undefined.
     * @return a new ligatureProcessor object. */
    namespace.makeLigatureProcessor = function (
        userDictionarySearch,
        wordDictionarySearch
        /* TODO support for compounds
        abCompoundDictionarySearch,
        cCompoundDictionarySearch
        */
    ) {
        var getRule,
            myFacturedObject,
            internalUserDictionarySearch,
            /* TODO support for compounds
            internalAbCompoundDictionarySearch,
            internalCCompoundDictionarySearch,
            */
            internalWordDictionarySearch;

        function validate(dictionary) {
            if (!NS.utilities.isFunctionObject(dictionary)) {
                if (NS.utilities.isNonvalue) {
                    return function () {
                        // just a dummy function
                        return undefined;
                    };
                }
                throw new Error("Invalid dictionary");
            }
            return dictionary;
        }

        internalUserDictionarySearch =
                validate(userDictionarySearch);
        internalWordDictionarySearch =
                validate(wordDictionarySearch);
        /* TODO support for compounds
        internalAbCompoundDictionarySearch =
                validate(abCompoundDictionarySearch);
        internalCCompoundDictionarySearch =
                validate(cCompoundDictionarySearch);
        */

        getRule = function (mySearchString) {
            // variable declarations
            var myLookupResult,
                myStatusCode,
                i,
                j,
                myPatternResult,
                temp;

            // Lookup for mySearchString in the dictionary files
            myLookupResult = internalUserDictionarySearch(mySearchString);
            if (NS.utilities.isNonvalue(myLookupResult)) {
                myLookupResult = internalWordDictionarySearch(mySearchString);
                /*if (NS.utilities.isNonvalue(myLookupResult)) {
                    // TODO Search for compounds (following the rules)
                }*/
            }

            // Remember if the direct lookup in the dictionary files
            // was successfull
            if (!NS.utilities.isNonvalue(myLookupResult)) {
                myStatusCode = 2;
            } else {
                myStatusCode = 3;
            }

            // If the word is not in the dictionary (following the
            // rules), we will just guess ...
            if (NS.utilities.isNonvalue(myLookupResult)) {
                /* TODO Before using the pattern, we could first
                 * 1. Search in a compound dictionary (the german hunspell
                 *    dictionary), treating each part
                 *    of the compound as simple words (= first look in the
                 *    dictionary, and if failed: look at the pattern).
                 * 2. Try to find a compound also against the rules
                 * I think at least (1) would help us a lot and
                 * make the hyphenation of compounds better. I am
                 * not so sure if (2) is a good idea...
                 */
                myLookupResult = "";
                myPatternResult = NS.patlib.applyPattern(mySearchString);
                for (i = 0; i < myPatternResult.length; i += 1) {
                    // add a "0" for all but the last codepoints of the
                    // current part ...
                    temp = NS.stringlib.countCodepoints(myPatternResult[i]) - 1;
                    for (j = 0; j < temp; j += 1) {
                        myLookupResult += "0";
                    }
                    // If there are other parts to come, use a "1" for the
                    // last codepoint of the current part...
                    if (i < myPatternResult.length - 1) {
                        myLookupResult += "1";
                    } else {
                        myLookupResult += "0";
                    }
                }
            }

            // return
            return {
                lookupResult: myLookupResult,
                statusCode: myStatusCode
            };
        };

        /**
         * @class ligatureProcessor
         */
        myFacturedObject = {};

        /**
         * @method getWordInstructions
         */
        myFacturedObject.getWordInstructions = function (
            myString
        ) {
            return internal_makeWordInstructions(
                myString,
                getRule
            );
        };

        // TODO check arguments for valid content

        return myFacturedObject;
    };

}(NS.getNamespaceObject("liglib"))); // available at this namespace

// *****************************************************************************
// ExtendScript library: extendscript

/**
 * This statement makes some utilities for ExtendScript available.
 * @class NS.extendscript
 */
(function (namespace) {

    /**
     * Calls myWindow.show(). Returns the return value of myWindow.show().
     * Furthermore, this function takes care of the position of the dialog.
     * If you use this function for various dialogs that show up consecutivly,
     * the dialogs will always show up at the position where the previous
     * one was closed.
     * @method showWindowWithAutomaticPosition
     * @param myWindow
     */
    namespace.showWindowWithAutomaticPosition = (function () {
        var oldLocation;

        return function (myWindow) {
            var myReturnValue;

            // restore the location of the previous dialog
            if (!NS.utilities.isNonvalue(oldLocation)) {
                myWindow.location = oldLocation;
            } else {
                // center the window relative to the screen
                /* (It would be better to center it relative to the InDesign
                 * main window, but this seems to be impossible with the
                 * interface that is provided by InDesign.) */
                myWindow.center();
            }

            // show dialog
            myReturnValue = myWindow.show();

            // save the position of the dialog
            oldLocation = myWindow.location;

            // return
            return myReturnValue;
        };
    }());

    /**
     * WARNING: To support resizable dialogs, the dialog properties
     * onResize, onResizing and onShow are changed. And you may not change
     * them again (otherwise the resizing will not work fine).
     * @method makeResizableDialog
     * @param title
     * @return a dialog that is resizable
     */
    namespace.makeResizableDialog = function (title) {
        // variable declarations
        var myDialog,
            myResizeFunction;

        // set up the dialog itself
        myDialog = new Window(
            "dialog",
            title,
            undefined,
            {resizeable: true}
        );

        // Trigger the resize of the child element when necessary
        myResizeFunction = function () {
            myDialog.layout.resize();
        };
        myDialog.onResize = myResizeFunction;
        myDialog.onResizing = myResizeFunction;

        // This function defines correctly the minimumSize property for
        // myWizard. As this is not done automatically by Adobe ScriptUI,
        // so we have to do it manually.
        myDialog.onShow = function () {
            var i;
            // define the initial standard size as minimum size for this
            // window and
            // its direct children
            myDialog.minimumSize = myDialog.size;
            for (i = 0; i < myDialog.children.length; i += 1) {
                // define the initial standard size as minimum size also for all
                // direct children
                myDialog.children[i].minimumSize = myDialog.children[i].size;
            }
        };

        // return
        return myDialog;
    };

    /**
     * Returns a modal message dialog with an "Close" button. (Function of
     * the button: "OK").
     * myMessage is the string that is displayed as message.
     * No automatic line break is done.
     * myDialogTitle is the string that is displayed as window title.
     * @method myDisplayMessageDialog
     * @param myMessage {String} The message text
     * @param myDialogTitle {String} The title of the window
     * @param myButtonText {String} optional. This
     * is used as text for the button.
     * @param myMultiline {Boolean} optional. If true, the text can be
     * broken in multiple lines.
     * @param mySize {Array} optional. Array of two numbers (size of the
     * window).
     * @return {Object} The dialog. Call .show() to display it.
     */
    namespace.myDisplayMessageDialog = function (
        myMessage,
        myDialogTitle,
        myButtonText,
        myMultiline,
        mySize
    ) {
        // declare variables
        var myDialog,
            myStaticText,
            internalButtonText;

        // do the work
        if (NS.utilities.isString(myDialogTitle)) {
            myDialog = new Window("dialog", myDialogTitle);
        } else {
            myDialog = new Window("dialog");
        }
        if (!NS.utilities.isNonvalue(mySize)) {
            myDialog.preferredSize = mySize;
        }
        myStaticText = myDialog.add(
            "statictext",
            undefined,
            undefined,
            {multiline: (myMultiline === true)}
        );
        myStaticText.alignment = "fill";
        if (NS.utilities.isString(myMessage)) {
            myStaticText.text = myMessage;
        }

        // add "close" button to the control area
        if (NS.utilities.isString(myButtonText)) {
            internalButtonText = myButtonText;
        } else {
            internalButtonText = localize({en: "Close", de: "Schlie\u00DFen"});
        }
        myDialog.add(
            "button",
            undefined,
            internalButtonText,
            // This makes that the button closes the dialog
            {name: "OK"}
        );

        return myDialog;
    };

    /**
     * @method makeProgressIndicator
     * @return {Object} a progressIndicatorObject
     */
    namespace.makeProgressIndicator = function () {
        /**
         * A non-modal progress indicator window
         * @class progressIndicatorObject
         */
        var returnValue = {},
            /**
             * @property myPaletteWindow {Object} the window
             * @private
             */
            myPaletteWindow,
            myMinimum = 0,
            myMaximum = 100,
            myValue = 0,
            myPercent = 0;

        myPaletteWindow = new Window("palette");
        myPaletteWindow.myLabel = myPaletteWindow.add(
            'statictext {characters: 10, justify: "right"}'
        );

        /**
         * Shows the progress indicator.
         * @method show
         */
        returnValue.show = function () {
            myPaletteWindow.show();
        };

        /**
         * Shows the progress indicator.
         * @method hide
         */
        returnValue.hide = function () {
            myPaletteWindow.hide();
        };

        function update() {
            myPercent = (myValue - myMinimum) * 100 / (myMaximum - myMinimum);
            if (myPercent < 0) {
                myPercent = 0;
            } else {
                if (myPercent > 100) {
                    myPercent = 100;
                }
            }
            // Percent value with one digit after decimal separator,
            // and a \u202F NARROW NO-BREAK SPACE before the % sign.
            myPaletteWindow.myLabel.text = NS.stringlib.replace(
                myPercent.toFixed(1) + "\u202F%",
                ".",
                ","
            );
        }

        /**
         * Sets the minimum.
         * @method setMinimum
         * @param minimum {Number} A finite number that indicates the minimum
         * of the progress indicator.
         */
        returnValue.setMinimum = function (minimum) {
            if (!NS.utilities.isFiniteNumber(minimum)) {
                throw new Error("minimum should be a finite number.");
            }
            myMinimum = minimum;
        };

        /**
         * Sets the maximum.
         * @method setMaximum
         * @param maximum {Number} A finite number that indicates the maximum
         * of the progress indicator.
         */
        returnValue.setMaximum = function (maximum) {
            if (!NS.utilities.isFiniteNumber(maximum)) {
                throw new Error("maximum should be a finite number.");
            }
            myMaximum = maximum;
        };

        /**
         * Sets the current value.
         * @method setValue
         * @param value {Number} A finite number that indicates the current
         * value of the progress indicator.
         */
        returnValue.setValue = function (value) {
            if (!NS.utilities.isFiniteNumber(value)) {
                throw new Error("value should be a finite number.");
            }
            myValue = value;
            update();
        };

        /**
         * Sets the window title.
         * @method setWindowTitle
         * @param title {String} The window title.
         */
        returnValue.setWindowTitle = function (title) {
            if (!NS.utilities.isString(title)) {
                throw new Error("title should be a string.");
            }
            myPaletteWindow.text = title;
        };

        return returnValue;
    };

    /**
     * Returns a File object for the currently running script file.
     * This is not trivial, because <code>app.activeScript</code> crashs
     * when the script is executed within ExtendScript Tooolkit (and bound
     * to an application like Indesign). Use this function instead,
     * which should be more stable.
     * @method currentScriptFile
     * @for NS.extendscript
     * @return {Object} An ExtendScript File object for the currently running
     * script file. Which file this is may depend on various conditions.
     * When you incluse this library with ExtendScripts <code>#include</code>
     * directive, than it will return the file of this library file. When
     * you use <code>eval()</code> to include it, than it will return the file
     * that executed the <code>eval()</code> statement.
     */
    namespace.currentScriptFile = function () {
        var myReturnValue = new File($.fileName);
        // As far as I know, this should always be correct. But just to be sure,
        // we test something ...
        if (!myReturnValue.exists) {
            throw new Error("Error while accessing current script file");
        }
        return myReturnValue;
    };

    /**
     * Preconditions: none
     * Each value except undefined and null have a "[[Class]] internal
     * property". This is a string that describes the class. It can have values
     * like "Boolean" for ECMAScript Boolean values, or like "Document" for
     * Indesign Document Objects. In general, this function produces more
     * usable values for ExtendScript Object than the .toString() function
     * (which is really inpredictable in ExtendScript).
     * See getConstructorName() for an alternative approach.
     * @method getClass
     * @param myValue {Any}
     * @return {String or Undefined} If myValue has a "[[class]] internal
     * property" it returns its content (a string). Otherwise undefined.
     */
    namespace.getClass = function (myValue) {
        if (NS.utilities.isNonvalue(myValue)) {
            /* Non-values do not have a "[[class]] internal property". Any
             * access to .__class__ leads to a runtime error. So we avoid
             * a call of .__class__ for non-values. */
            return undefined;
        }
        // This is tested with Indesign 6 (32 bit) at Windows 8.1 (64 bit).
        // But I suppose that this works also for other environments.
        return myValue.__class__;
    };

    /**
     * Preconditions: none
     * Each value except undefined and null have a constructor name.
     * It can have values
     * like "Boolean" for ECMAScript Boolean values, or like "Document" for
     * Indesign Document Objects. In general, this function produces more
     * usable values for ExtendScript Object than the .toString() function.
     * However, as it accesses simply the constructor name, users could
     * create their own constructors with for example the name "Document"
     * and theirfor create values that have getConstructorName === "Document".
     * So the use of getConstructorName() can be ambiguous.
     * See getClass() for another, probably better approach that avoids this
     * ambigouity.
     * @method getConstructorName
     * @param myValue {Any}
     * @return {String or Undefined} If myValue has a "[[class]] internal
     * property" it returns its content (a string). Otherwise undefined.
     */
    namespace.getConstructorName = function (myValue) {
        if (NS.utilities.isNonvalue(myValue)) {
            /* Non-values do not have a constructor property. Any
             * access to .constructor leads to a runtime error. So we avoid
             * a call of .constructor for non-values. */
            return undefined;
        }
        // This is tested with Indesign 6 (32 bit) at Windows 8.1 (64 bit).
        // (While not all environments support the .name property for the
        // constructor, most of them do.)
        return myValue.constructor.name;
    };

    /**
     * Re-resolves mySpecifierObject.
     *
     * The objects of Adobes Script DOM are a sort of specifiers. Example:
     * You have the string "abcd" in your first text element. You get access to
     * the character with the index 2 ("c") when you use
     * <code>var test = app.activeDocument.stories[0].characters[2]</code>.
     * Maybe later you insert "x" between "a" and "b". So you have "axbcd".
     * <code>test</code> points still to the letter "c", which has now the
     * index 3. If you call <code>reResolve(test)</code>, then the original
     * access specifier is re-resolved again, so now it will point to the
     * current character at index position 2, which is now "b".
     * @method reResolve
     * @param mySpecifierObject
     */
    namespace.reResolve = function (mySpecifierObject) {
        mySpecifierObject.getElements();
    };

    /**
     * Preconditions: none
     *
     * It is always safe to call this function, even if myVariable is
     * <code>undefined</code> or <code>null</code>.
     *
     * You should use this function instead of NS.utilities.isArrayObject
     * when you work in ExtendScript. Because ExtendScript is a broken
     * implementation of ECMAScript, NS.utilities.isArrayObject does not work
     * well on ExtendScript. Use this hack instead.
     * @method isArrayObject
     * @param myVariable
     * @return <code>true</code> is myVariable is an array object,
     * otherwise <code>false</code>.
     */
    namespace.isArrayObject = function (myVariable) {
        /* The only reliable way in ECMAScript 3 to check if a value is a
         * certain build-in object like Array is:
         *
         * Object.prototype.toString.call(myVariable) === "[object Array]"
         *
         * Unfourtunally, this does not work for ExtendScript, because
         * ExtendScript is not a standard-conform implementation of
         * ECMAScript 3, but broken (yet by design). Especially,
         * Object.prototype.toString.call() does not work like it would have
         * to work following the ECMAScript standard. For user-created arrays,
         * you get "[object Array]", but for system-created arrays, you get
         * maybe for Characters.getElements() something like
         * "[object Character],[object Character],[object Character]".
         * Nevertheless it is a real array. So we need a fallback for this.
         * The internal [[Class]] property seems to work quite reliable...
         */
        return (namespace.getClass(myVariable) === "Array");
    };

    /**
     * Preconditions: none
     * It is always safe to call this function, even if myVariable is
     * <code>undefined</code> or <code>null</code>.
     * @method isHostObject
     * @param myVariable
     * @return <code>true</code> is myVariable is a host object,
     * otherwise <code>false</code>.
     */
    namespace.isHostObject = function (myValue) {
        /*
         * For both, ECMAScript 3 and ECMAScript 5.1, the [[Class]] property
         * is mandatory for host objects. About the content:
         *
         * ECMAScript 3 says:
         * The value of the [[Class]] property is defined by this specification
         * for every kind of built-in object. The value of the [[Class]]
         * property of a host object may be any value, even a value used by a
         * built-in object for its [[Class]] property. The value of a [[Class]]
         * property is used internally to distinguish different kinds of
         * built-in objects. Note that this specification does not provide any
         * means for a program to access that value except through
         * Object.prototype.toString (see 15.2.4.2).
         *
         * ECMAScript 5.1 says:
         * The value of the [[Class]] internal property is defined by this
         * specification for every kind of built-in object. The value of the
         * [[Class]] internal property of a host object may be any String value
         * except one of "Arguments", "Array", "Boolean", "Date", "Error",
         * "Function", "JSON", "Math", "Number", "Object", "RegExp", and
         * "String". The value of a [[Class]] internal property is used
         * internally to distinguish different kinds of objects. Note that this
         * specification does not provide any means for a program to access that
         * value except through Object.prototype.toString (see 15.2.4.2).
         *
         * So there is no reliable way to detect host objects in ECMAScript 3,
         * but only since 5.1. As far as I could observe, ExtendScript (which
         * is ECMAScript 3 based) does not use [[Class]] values that conflict
         * with build-in objects. That is good. On the other hand, in
         * ExtendScript, the Object.prototype.toString function is broken.
         * That is bad. We use our own getClass() function instead.
         */
        if (!NS.utilities.isObject(myValue)) {
            return false;
        }
        switch (namespace.getClass(myValue)) {
        case "Arguments":
        case "Array":
        case "Boolean":
        case "Date":
        case "Error":
        case "Function":
        case "JSON":
        case "Math":
        case "Number":
        case "Object":
        case "RegExp":
        case "String":
            return false;
        }
        return true;
    };

}(NS.getNamespaceObject("extendscript"))); // available at this namespace

// *****************************************************************************
// Indesign library: indesign

/**
 * Adds some useful things that help to deal with Indesign.
 * @class NS.indesign
 */
(function (namespace) {

    /**
     * Scroll the view to myText and selects myText. myText must be an Adobe
     * text object.
     * @method exposeText
     * @param myText
     */
    namespace.exposeText = function (myText) {
        app.select(myText);
        myText.showText(); // claimed to work starting with Indesign 5

        /* An alternative approach would be this one:
         *
         * app.layoutWindows[0].zoomPercentage =
         *         app.layoutWindows[0].zoomPercentage;
         *
         * This is claimed to work also with older Indesign versions. However,
         * when being at maximal zoom 3200, than reassigning the very same
         * value fails with an exception. Apparently this is a bug
         * in Indesign. */
    };

    /**
     * Preconditions: Must be executed within Indesign.
     * @method getCurrentTextSelection
     * @return {Array} An array of Text Objects. It contains all Text Objects
     * that are selected with the text selection tool. If no Text Object is
     * selected with the text selection tool, than the array is
     * empty. Note that the Text Objects in the array may have an empty content
     * (for example for the content of selected, but empty table cells).
     */
    namespace.getCurrentTextSelection = function () {
        // variable declarations
        var i,
            myReturnValue;

        // code
        myReturnValue = [];
        // Get the current selection
        // If the selection contains more than one item, then the selection
        // was not text selected with the Type tool.
        if (app.selection.length === 1) {
            // Test if the selection is really text.
            switch (app.selection[0].constructor.name) {
            case "Character":
            case "Word":
            case "TextStyleRange":
            case "Line":
            case "Paragraph":
            case "TextColumn":
            case "Text":
            case "Story": // could not produce a Story selection while testing
                myReturnValue.push(app.selection[0].texts[0]);
                break;
            case "Cell":
            case "Table":
                for (i = 0; i < app.selection[0].cells.count(); i += 1) {
                    myReturnValue.push(
                        app.selection[0].cells.item(i).texts.item(0)
                    );
                }
                break;
            }
        }

        return myReturnValue;
    };

    /**
     * Returns true if myLanguage is a variant of german.
     * Otherwise returns false.
     * myLanguage can be either of type "Language" or "LanguageWithVendor".
     * @method myIsGerman
     * @param myLanguage
     */
    namespace.myIsGerman = function (myLanguage) {
        // declare variables
        var myHasGermanIcuLocaleName,
            myKeyStrings,
            myIsNoLanguage,
            i;

        // test if the locale is a german locale
        myHasGermanIcuLocaleName =
                /^de(u|@|_|$)/.test(myLanguage.icuLocaleName);

        // test if it is a "No language".
        // (Even "No language" kann have an icuLocaleName like de_DE. So it is
        // not enought to check just the icuLocaleName. We have to do also the
        // special check that comes here.)
        myKeyStrings = app.findKeyStrings(myLanguage.name);
        myIsNoLanguage = false;
        for (i = 0; i < myKeyStrings.length; i += 1) {
            if (
                (myKeyStrings[i] === "$ID/[No Language]") ||
                    (myKeyStrings[i] === "$ID/[No language]")
            ) {
                myIsNoLanguage = true;
                break;
            }
        }

        // return
        return Boolean(myHasGermanIcuLocaleName && (!myIsNoLanguage));
    };

    /**
     * Preconditions: none
     * @method isStory
     * @param myValue {Any}
     * @return {Boolean} True if myValue is a Story.
     * Otherwise returns false.
     */
    namespace.isStory = function (myValue) {
        // test if this is an object (Indesign returns sometimes object-like
        // values that are not objects. It is better to check ...)
        if (NS.utilities.isObject(myValue)) {
            if (NS.extendscript.getClass(myValue) === "Story") {
                return true;
            }
        }
        return false;
    };

    /**
     * Preconditions: none
     *
     * Note: isText(Story) returns false because Story is not a sub-class of
     * Text. However, Story Ojects behaves a little bit like Story objects.
     * So maybe, you want to use something like
     * <code>NS.indesign.isStory(myValue) || NS.indesign.isText(myValue)</code>
     * in your code.
     * @method isText
     * @param myValue {Any}
     * @return {Boolean} True if myValue is a Text or one of its sub-classes.
     * Otherwise returns false.
     */
    namespace.isText = function (myValue) {
        // test if this is an object (Indesign returns sometimes object-like
        // values that are not objects. It is better to check ...)
        if (NS.utilities.isObject(myValue)) {
            switch (NS.extendscript.getClass(myValue)) {
            // test for the base class ...
            case "Text":
            // test for the subclasses (as known in Indesign CS 6) ...
            case "Character":
            case "InsertionPoint":
            case "Line":
            case "Paragraph":
            case "TextColumn":
            case "TextStyleRange":
            case "Word":
                return true;
            }
        }
        return false;
    };

    /**
     * Preconditions: none
     * @method isDocument
     * @param myValue {Any}
     * @return {Boolean} True if myValue is a Document.
     * Otherwise returns false.
     */
    namespace.isDocument = function (myValue) {
        // test if this is an object (Indesign returns sometimes object-like
        // values that are not objects. It is better to check ...)
        if (NS.utilities.isObject(myValue) &&
                NS.extendscript.getClass(myValue) === "Document") {
            return true;
        }
        return false;
    };

    /**
     * Preconditions: myText is a valid text object.
     * This function returns all text elements within an Adobe text
     * element myText. This is not trivial. Adobe text elements
     * (specially Story.texts[0] elements) can contain additionally to their
     * direct text content also nested objects that also contain text,
     * but this text is not part of the direct text content of the parent.
     * Examples are tables and footnotes.
     *
     * This function returns an array of Adobe Text
     * objects. This array contains myText itself and also all the text of all
     * tables, even for nested tables, and for all footnotes and for all tables
     * within footnotes and so on.
     * It does not return hidden text (conditional text that is currently
     * hidden). An example for conditional text would be "tree(s)". "Tree" would
     * be displayed always (unconditonal text), and "s" would be displayed only
     * if we talk about 2, 3 or more trees. If we would process hidden text, we
     * would get "s" as an own text element. But it is just a part of a word,
     * not a complete word. We do not want this behaviour here.
     * @method getAllTexts
     * @param myText {Object} An Indesign Text Object
     * @return {Array} An array of Text objects
     */
    namespace.getAllTexts = function (myText) {
        // declare variables
        var myReturnValue = [],
            i,
            j;

        // add the original text itself to our return value
        myReturnValue.push(myText);

        // add the text that is within tables
        for (i = 0; i < myText.tables.count(); i += 1) {
            for (j = 0; j < myText.tables.item(i).cells.count(); j += 1) {
                myReturnValue = myReturnValue.concat(
                    namespace.getAllTexts(
                        myText.tables.item(i).cells.item(j).texts.item(0)
                    )
                );
            }
        }

        // add the text that is within footnotes
        for (i = 0; i < myText.footnotes.count(); i += 1) {
            for (j = 0; j < myText.footnotes.item(i).texts.count(); j += 1) {
                myReturnValue = myReturnValue.concat(
                    namespace.getAllTexts(
                        myText.footnotes.item(i).texts.item(j)
                    )
                );
            }
        }

        // return
        return myReturnValue;
    };

    /**
     * This function returns all text elements within an Adobe document
     * myDocument. This is not trivial. Adobe text elements
     * (specially Adobe story elements) can contain additionally to their
     * direct text content also nested objects that also contain text,
     * but this text is not part of the direct text content of the parent.
     * Examples are tables and footnotes.
     *
     * This function returns an array of Adobe Text
     * objects. This array contains all the texts, also of all
     * tables, even for nested tables, and for all footnotes and for all tables
     * within footnotes and so on. Of course, it returns also all path texts
     * (text that is aligned to circles or within rectangles).
     *
     * It does not return hidden text (conditional text that is currently
     * hidden). An example for conditional text would be "tree(s)". "Tree" would
     * be displayed always (unconditonal text), and "s" would be displayed only
     * if we talk about 2, 3 or more trees. If we would process hidden text, we
     * would get "s" as an own text element. But it is just a part of a word,
     * not a complete word. We do not want this behaviour here.
     * @method getAllDocumentTexts
     * @param myDocument {Object} An Indesign Document Object
     * @return {Array} An array of Text objects
     */
    namespace.getAllDocumentTexts = function (myDocument) {
        // Initialize this variable as an empty array
        var myTexts = [],
            i;
        // Add all stories to the array
        for (i = 0; i < myDocument.stories.count(); i += 1) {
            myTexts = myTexts.concat(
                NS.indesign.getAllTexts(myDocument.stories.item(i).texts[0])
            );
        }
        return myTexts;
    };

    /**
     * Get the contents property of a text object as string.
     *
     * Indesigns build-in <code>.contents</code> property returns sometimes a
     * string and sometimes an enumerator. Furthermore, it seems to be cached
     * and sometimes returns outdated content. Use this function insteand, and
     * you can be sure to get always a string (and never an enumerator) that
     * is always in sync (and never outdated).
     *
     * Note: This function does not re-resolve the specifier.
     * @method getContentsString
     * @param myTextObject {Object} A text object.
     * @return {String} The content of the text object.
     */
    namespace.getContentsString = function (myTextObject) {
        /* Adobe does not provide a clear documentation about when
         * the text.contents property returns a string and when it
         * returns a SpecialCharacters enumerator. But it seems that
         * you get the SpecialCharacters enumerator always if the
         * text contains exactly one codepoint and this codepoint is
         * one of these that have a representation as SpecialCharacters
         * and the text object is also a character object. In all other
         * cases (zero codepoints; one codepoint, but not a special
         * codepoint; a special codepoint, but the text object is not
         * also a character object; more than one codepoint) we get a
         * string. As myTextObject may or may not be a character obejct,
         * we make sure to work with a non-character object as provider
         * for the content. */
        /* Furthermore, the content property seems to be sometimes out
         * of sync after changes that have been made. Using
         * .texts[0].contents means to create a new object with its
         * own content property which will be in sync (because it is
         * recently created). Using .texts[0].contents furthermore
         * does not re-resolve the specifier of myTextObject itself;
         * this behaviour is useful.
         */
        var myReturnValue = myTextObject.texts[0].contents;
        /* myReturnValue should now contain a string. But I do not
         * trust Indesign. And I never know if Indesign changes its
         * object model in the next version. So I make at least a
         * little check here. */
        if (!NS.utilities.isString(myReturnValue)) {
            throw new Error(
                "Could not convert text object to string. This is a bug."
            );
        }
        // Return our string
        return myReturnValue;
    };

    /**
     * Indesign Text objects provides collections (like Characters or
     * Paragraphs) that provide a method .itemByRange, but this
     * method delivers strange types (objects that seem to be Text objects,
     * but their .contents property returns arrays and so on ...). This
     * function is a replacement that should return really a normal
     * Text object.
     *
     * This function is experimentell. Test it before you use it!
     * @method getTextFromItemByRange
     * @param myCollection {Object} A collection (like Characters or
     * Paragraphs).
     * @param from {Varies} Argument that is passed to the native .itemByRange
     * method.
     * @param to {Varies} Argument that is passed to the native .itemByRange
     * method.
     * @return {Object} A normal Text Object.
     */
    namespace.getTextFromItemByRange = function (myCollection, from, to) {
        /* The idea comes from a discussion in the the Adobe
         * forums (https://forums.adobe.com/message/4745382).
         * I do not really understand why it works, but it
         * works!
         */
        return myCollection.itemByRange(from, to).getElements()[0];
    };

    /**
     * Preconditions: myText is a non-empty text object.
     * (TODO Does is work with insertion points???)
     * @method getNextCharacter
     * @param myText {Object} A text object.
     * @return {Object} If there is a next character, then the corresponding
     * character object. Otherwise undefined.
     */
    namespace.getNextCharacter = function (myText) {
        var lastCharacter = myText.characters.lastItem(),
            parentCharactersCollection =
                    lastCharacter.parent.characters,
            nextCharacterIndex = lastCharacter.index + 1;
        if (nextCharacterIndex < parentCharactersCollection.count()) {
            return parentCharactersCollection.item(nextCharacterIndex);
        }
        return undefined;
    };

    /**
     * Preconditions: myText is a non-empty text object.
     * (TODO Does is work with insertion points???)
     * @method getPreviousCharacter
     * @param myText {Object} A text object.
     * @return {Object} If there is a previous character, then the corresponding
     * character object. Otherwise undefined.
     */
    namespace.getPreviousCharacter = function (myText) {
        var firstCharacter = myText.characters.firstItem(),
            parentCharactersCollection =
                    firstCharacter.parent.characters,
            firstCharacterIndex = firstCharacter.index,
            previousCharacterIndex = firstCharacterIndex - 1;
        if (previousCharacterIndex >= 0) {
            return parentCharactersCollection.item(previousCharacterIndex);
        }
        return undefined;
    };
// TODO Sortierung auch tatsaechlich fuer unsere Stories verwenden!
    /**
     * Preconditions: myStory must be a valid Story Object.
     * @method getStartPageFromStory
     * @param myStory {Object} A valid Story Object
     * @return {Object} The Page Object of the page on which this story
     * starts.
     */
    namespace.getStartPageFromStory = function (myStory) {
        // variable declarations
        var myContainer,
            myReturnValue;

        // check preconditions
        if (NS.extendscript.getClass(myStory) !== "Story") {
            throw new Error("Bad argument. Should be a Story object.");
        }

        // initialization
        myContainer = myStory.textContainers[0];

        // get the Page Object
        if (NS.extendscript.getClass(myContainer) === "TextFrame") {
            myReturnValue = myContainer.parentPage;
            if (NS.extendscript.getClass(myReturnValue) !== "Page") {
                // This should never happen ...
                throw new Error("Failed to get Page from TextFrame.");
            }
            return myReturnValue;
        }
        if (NS.extendscript.getClass(myContainer) === "TextPath") {
            myReturnValue = myContainer.parent.parentPage;
            if (NS.extendscript.getClass(myReturnValue) !== "Page") {
                // This should never happen ...
                throw new Error("Failed to get Page from TextPath.");
            }
            return myReturnValue;
        }

        // Fallback
        // This should never happen ...
        throw new Error("Failed to get an expected container from Story.");
    };

    /**
     * @method makeWordIterator
     * @param myElements {Array} An array of elements. May contain Text Objects
     * or any of the subclasses of Text Objects or Story Objects.
     * @param myMode {String} Either "flat" or "deep"
     * @return {Object} A wordIterator object.
     */
    namespace.makeWordIterator = function (myElements, myMode) {
        /**
         * wordIterator objects help iterating word-by-word through Indesign
         * Text objects. They do not use Indesigns quite simple build-in
         * word boundary rules, but real Unicode-TR29 word boundary rules.
         * (That means that also spaces are treated as own words).
         *
         * Note that some special elements like tables are represented as
         * control characters in the sourrounding text. So the word
         * boundary algorithm will break there (while Indesign itself does
         * not consider this as word boundary).
         * @class wordIterator
         */
        // variable declarations
        var myReturnValue = {},
            deepMode,
            myStack,
            i;

        // check preconditions
        if (!NS.extendscript.isArrayObject(myElements)) {
            throw new Error("myElements must be an Array.");
        }
        switch (myMode) {
        case "flat":
        case "deep":
            break;
        default:
            throw new Error("myMode is invalid.");
        }

        // initialization of mode
        if (myMode === "deep") {
            deepMode = true;
        } else {
            deepMode = false;
        }

        /**
         * Pushes myText to the stack.
         * @method pushTextToStack
         * @private
         * @param myText {Object} A Text Object (also sub-classes) or a
         * Story Object.
         */
        function pushTextToStack(myText) {
            var element,
                myNextWordStartCharacter,
                myPreviousCharacter,
                myParent,
                myWordBoundaryDetector,
                j;
            // check pre-conditions
            element = myText;
            NS.extendscript.reResolve(element);
            if (!namespace.isText(element) &&
                    !namespace.isStory(element)) {
                throw new Error("Element " + j + " is invalid.");
            }
            // normalize to a standard Text object
            element = element.texts[0];
            // initialization
            myNextWordStartCharacter = element.characters.firstItem();
            if (NS.utilities.isNonvalue(myNextWordStartCharacter)) {
                // The text is empty. So no need to add it. (Adding it would
                // also make problems when working with
                // myNextWordStartCharacter.parent)
                return;
            }
            myParent = myNextWordStartCharacter.parent;
            function myCallback(index) {
                if ((index >= 0) && (index < myParent.characters.length)) {
                    return NS.indesign.getContentsString(
                        myParent.characters.item(index)
                    );
                }
                return undefined;
            }
            myWordBoundaryDetector = NS.wordboundary.makeWordBoundaryDetector(
                myCallback
            );
            myWordBoundaryDetector.setTailorSpacesAsThousandsSeparators(true);
            // Skip the first word of myText if this is only a partial word
            myPreviousCharacter = namespace.getPreviousCharacter(
                myNextWordStartCharacter
            );
            if (!NS.utilities.isNonvalue(myPreviousCharacter)) {
                j = myPreviousCharacter.index;
                while (!myWordBoundaryDetector.isWordBoundary(j)) {
                    j += 1;
                }
                j += 1;
                if (j < myParent.characters.length) {
                    myNextWordStartCharacter = myParent.characters.item(j);
                } else {
                    myNextWordStartCharacter = undefined;
                }
            }
            // depending on the control flow, myNextWordStartCharacter may
            // or may not be resolved. It is better to have a defined and
            // reliable behaviour, so we make sure that it is always resolved:
            if (!NS.utilities.isNonvalue(myNextWordStartCharacter)) {
                NS.extendscript.reResolve(myNextWordStartCharacter);
            }
            // push now everything to the stack
            myStack.push({
                myParent: myParent,
                nextWordStartCharacter: myNextWordStartCharacter,
                myEndCharacter: element.characters.lastItem(),
                myWordBoundaryDetector: myWordBoundaryDetector
            });
        }

        // initialization of stack
        myStack = [];
        for (i = myElements.length - 1; i >= 0; i -= 1) {
            pushTextToStack(myElements[i]);
        }

        /**
         * Moves on the iteration. If on the given element, there is
         * still a word to return, it moves to this word and returns it.
         * If on the stack current element, there are no more words to return,
         * than it returns a non-value.
         * @method getWordFromElement
         * @param myElement The element where the next word is searched.
         * @private
         * @return An Indesign text object for the next word within the current
         * element (if any). Otherwise returns a non-value.
         */
        function getWordFromElement(myElement) {
            var currentWordStartCharacterIndex,
                currentWordEndCharacterIndex,
                currentWord;
            // Test preconditions
            if (!NS.utilities.isObject(myElement)) {
                $.writeln(NS.utilities.myDataIntrospection(myElement));
                throw new Error("Invalid argument (not an object).");
            }
            // Test if the next character is out of our current
            // element's text.
            if (NS.utilities.isNonvalue(myElement.nextWordStartCharacter)) {
                // end is reached
                return undefined;
            }
            // update ...
            currentWordStartCharacterIndex =
                    myElement.nextWordStartCharacter.index;
            currentWordEndCharacterIndex = currentWordStartCharacterIndex;
            myElement.myWordBoundaryDetector.clearCache();
            while (!myElement
                .myWordBoundaryDetector
                .isWordBoundary(currentWordEndCharacterIndex)) {
                currentWordEndCharacterIndex += 1;
            }
            // check if we have run out of range of our text selection
            if (currentWordEndCharacterIndex >
                    myElement.myEndCharacter.index) {
                myElement.nextWordStartCharacter = undefined;
                return undefined;
            }
            currentWord = namespace.getTextFromItemByRange(
                myElement.myParent.characters,
                currentWordStartCharacterIndex,
                currentWordEndCharacterIndex
            );
            if ((currentWordEndCharacterIndex + 1) <
                    myElement.myParent.characters.length) {
                myElement.nextWordStartCharacter = myElement
                    .myParent
                    .characters
                    .item(currentWordEndCharacterIndex + 1);
                NS.extendscript.reResolve(myElement.nextWordStartCharacter);
            } else {
                myElement.nextWordStartCharacter = undefined;
            }
            // return
            return currentWord;
        }

        /**
         * @method getNextWord
         * @return An Indesign text object for the next word (if any). Otherwise
         * returns a non-value.
         */
        myReturnValue.getNextWord = function () {
            var theWord;
            while ((myStack.length > 0) && NS.utilities.isNonvalue(theWord)) {
                theWord = getWordFromElement(myStack[myStack.length - 1]);
                if (NS.utilities.isNonvalue(theWord)) {
                    myStack.pop(); // remove the last element from the stack
                } else {
                    if (deepMode === true) {
                        /* Tables and footnotes within Text Objects are
                         * represented as control characters. As control
                         * characters are treated always as individual
                         * words by the word boundary algorithm (with some
                         * special behaviour for CR and LF, but this is not
                         * important here) we can be sure to not treat
                         * them double and to catch all of them. That means
                         * that each word has either 0 or 1 of tables. Same
                         * for footnotes. And there are never tables and
                         * footnotes within the same word.
                         */
                        if (theWord.tables.length > 0) {
                            for (
                                i = theWord.tables[0].cells.count() - 1;
                                i >= 0;
                                i -= 1
                            ) {
                                pushTextToStack(
                                    theWord.tables[0].cells[i].texts[0]
                                );
                            }
                            theWord = undefined;
                        } else {
                            if (theWord.footnotes.length > 0) {
                                pushTextToStack(theWord.footnotes[0].texts[0]);
                                theWord = undefined;
                            }
                        }
                    }
                }
            }
            return theWord;
        };

        // return
        return myReturnValue;
    };

}(NS.getNamespaceObject("indesign"))); // available at this namespace

// *****************************************************************************
// Indesign dictionary library: indict

/**
 * Adds dictionary access
 * @class NS.indict
 */
(function (namespace) {
    var myFileEncoding,
        fieldCodeunitLength,
        fieldByteLength,
        blockByteLength; // two fields

    /* We use the encoding UTF16 Little Endian. This is because "File", which
     * is provided by Adobe's ExtendScript (at least in InDesign CS6), seems
     * to have problems with UTF8 encoded files when the characters are outside
     * the Unicode BMP range. Also the auto-detection of the encoding and
     * of the byte order fails often. So a hard-coded UTF16 with a hard-coded
     * endianess is the only reliable solution.
     */
    myFileEncoding = "UTF16LE";
    fieldCodeunitLength = 50;
    fieldByteLength = 2 * fieldCodeunitLength;
    blockByteLength = 2 * fieldByteLength;

    /**
     * @method getFieldCodeunitLength
     * @return {Number} The length of a field in the dictionary file (the number
     * of UTF16 codeunits)
     */
    namespace.getFieldCodeunitLength = fieldCodeunitLength;

    /**
     * @method NS.indict.makeDictionaryObject
     * @param path The path to the file
     * @return a new dictionaryObject.
     */
    namespace.makeDictionaryObject = function (path) {
        /**
         * An object that provides access to a dictionary.
         * @class dictionaryObject
         */
        var myDictionaryObject = {},
            dictionaryFile,
            dictionaryFileLength,
            readKey,
            readValue,
            fileIsOpen;

        dictionaryFile = new File(path);
        if (!dictionaryFile.exists) {
            throw new Error("Could not open file: " + path);
        }
        dictionaryFile.encoding = myFileEncoding;
        // open the file in read-only mode "r"
        fileIsOpen = dictionaryFile.open("r");
        if (!fileIsOpen) {
            throw new Error("Could not open file: " + path);
        }
        dictionaryFileLength = dictionaryFile.length;

        // Test if the file length is a multiple of the expected block length
        if (Math.round(dictionaryFileLength / blockByteLength) !==
                (dictionaryFileLength / blockByteLength)) {
            throw new Error("Invalid file length: " + path);
        }

        // TODO teste die Endianess. Wir koennen das, weil auf Codeunit-Index
        // 48 und 49 (NS.indict.getFieldCodeunitLength - 1,
        // NS.indict.getFieldCodeunitLength - 2) die Zeichen CR + LF liegen
        // muessen. Falls das nicht so ist,
        // ist entweder Endianess falsch oder der Inhalt falsch.
        // DANGER Es ist sehr wichtig, das zu pruefen, denn wir verwenden
        // readln(), und wenn kein Zeilenumbruch erkannt wird, liest das
        // Programm riesige Datenmengen und es gibt "out of memory".

        readKey = function (index) {
            dictionaryFile.seek(index * blockByteLength);
            /* We use readln(). The normal read() does not work reliable. The
             * documentation claims that it counts Unicode codepoints (and not
             * codeunits). But at least for UTF16 the documentation seems to
             * be wrong. As it is not clear when read() counts codepoints and
             * when it counts codeunits, I prefer to avoid its usage. */
            return dictionaryFile.readln();
        };

        readValue = function (index) {
            dictionaryFile.seek((index * blockByteLength) + fieldByteLength);
            return dictionaryFile.readln();
        };

        /**
         * Searchs in the dictionary on the hard disc with a binary
         * search algorithm.
         * @method search
         * @param searchString {String} The key for that we search
         * @return {String or Undefined} If the key exists, it returns
         * its value (as string). Otherwise, it returns undefined.
         */
        myDictionaryObject.search = function (searchString) {
            var left = 0,
                middle,
                right = (dictionaryFileLength / blockByteLength) - 1,
                currentKey;

            // The string length in the dictionary is limited,
            // so if the search string is too long, there will be no
            // match and we can return inmediatly.
            // fieldCodeunitLength is reduced by 2 because of
            // the trailing CR + LF.
            if (searchString.length > (fieldCodeunitLength - 2)) {
                return undefined;
            }

            // The search string has to have the same length than
            // the field length.
            // fieldCodeunitLength is reduced by 2 because of
            // the trailing CR + LF.
            while (searchString.length < (fieldCodeunitLength - 2)) {
                searchString += " ";
            }
            // While the search domain is not empty ...
            while (left <= right) {
                middle = left + Math.round((right - left) / 2);
                currentKey = readKey(middle);
                if (currentKey === searchString) { // key found?
                    return NS.stringlib.replace(readValue(middle), " ", "");
                }
                if (currentKey > searchString) {
                    right = middle - 1; // continue search at the left part
                } else { // currentKey < searchString
                    left = middle + 1; // continue search at the right part
                }
            }
            return undefined;
        };

        return myDictionaryObject;
    };
}(NS.getNamespaceObject("indict"))); // available at this namespace

// *****************************************************************************
// Indesign ligature setting dialogs library: ligdialog

/**
 * Collection of dialogs that are used for our ligature setting.
 * @class NS.ligdialog
 */
(function (namespace) {
    var mySetUpControlArea,
        myStringLigatureFormat,
        /**
         * The variable that holds the character that is used as separator
         * character in the UI. It is a string that contains a character in
         * the BMP, so it is only one codeunit in UTF16.
         * @property separator
         * @type {String}
         * @private
         */
        separator = "=";

    /* Sets up the buttons in myGroup. */
    mySetUpControlArea = function (myGroup) {
        // general setup
        myGroup.alignment = ["fill", "bottom"];

        // add "help" button to the control area
        myGroup.helpButton = myGroup.add("button");
        myGroup.helpButton.text = localize({en: "Manual", de: "Handbuch"});
        myGroup.helpButton.onClick = NS.ligdialog.openManual;

        // add "dictionary" button to the control area
        myGroup.dictionaryButton = myGroup.add("button");
        myGroup.dictionaryButton.text = localize(
            {en: "User dictionary", de: "Benutzerw\u00F6rterbuch"}
        );
        myGroup.dictionaryButton.enabled = false;

        // add "cancel" button to the control area
        myGroup.cancelButton = myGroup.add(
            "button",
            undefined,
            localize({en: "Close", de: "Schlie\u00DFen"}),
          // This makes that the button really has this function:
            {name: "cancel"}
            // automatically.
        );

        // add "next" button to the control area
        myGroup.nextButton = myGroup.add(
            "button",
            undefined,
            localize({en: "Start", de: "Start"})
        );
        // TODO Alt+n Alt+x usw. (Shortcuts)
    };

    /**
     * A helper function. "separator" must be a string of exactly
     * 1 codepoint length.
     * @method myStringLigatureFormat
     * @private
     * @param string {String} It takes "string" and
     * @return A simplified version of the string: ZERO WIDTH NON-JOINER is
     * replaced by "separtor". Sequenzes of more than one consecutive
     * "separator" are replaced by a single "separator". Than, "separator" at
     * the start and at the end of the string are removed. */
    myStringLigatureFormat = function (string) {
        // variable declarations
        var myString;

        // initialize variables
        myString = string;

        // Test preconditions
        if (myString.indexOf(separator) >= 0) {
            throw new Error(
                "The parameter string may not contain the separator."
            );
        }

        // If ZERO WIDTH NON-JOINERs are there, they are
        // substituted by "separator"
        if (myString.indexOf("\u200C") >= 0) {
            myString = NS.stringlib.replace(myString, "\u200C", separator);
        }

        // Replace double separators with simple separators
        while (myString.indexOf(separator + separator) >= 0) {
            myString = NS.stringlib.replace(
                myString,
                separator + separator,
                separator
            );
        }

        // Remove leading separator
        if (myString.charAt(0) === separator) {
            myString = myString.slice(1);
        }

        // Remove leading separator
        if (myString.charAt(myString.length - 1) === separator) {
            myString = myString.slice(0, myString.length - 1);
        }

        // return
        return myString;
    };

    /**
     * @method getLocalizedTitle
     * @return {String} A localized string that can be used as title
     * for windows.
     */
    namespace.getLocalizedTitle = function () {
        return localize(
            {
                en: "Ligature setting for german text",
                de: "Ligatursatz f\u00FCr die deutsche Sprache"}
        );
    };

    /**
     * Adds an edittext field to myGroup. This edittext field is for determining
     * the ligature setting. It shows myContent. The ZERO WIDTH NON-JOINER is
     * substituted by separator (must be a single code point). Returns the
     * edittext field.
     * @method myAddLigatureEdit
     * @param myGroup
     * @param myOriginalWord
     */
    namespace.myAddLigatureEdit = function (
        myGroup,
        myOriginalWord
    ) {
        // variable declarations
        var myEdittext,
            myWithoutSeparatorsTemp,
            mySimplifiedTemp;

        // code
        myEdittext = myGroup.add("edittext");
        myEdittext.originalWordWithoutSeparators = NS.stringlib.replace(
            NS.stringlib.replace(myOriginalWord, "\u200C", ""),
            separator,
            ""
        );
        myEdittext.text = myStringLigatureFormat(
            myOriginalWord,
            separator
        );
        myEdittext.lastKnownContent = myEdittext.text;
        myEdittext.onChanging = function () {
            myWithoutSeparatorsTemp = NS.stringlib.replace(
                NS.stringlib.replace(myEdittext.text, "\u200C", ""),
                separator,
                ""
            );
            if (myWithoutSeparatorsTemp !==
                    myEdittext.originalWordWithoutSeparators) {
                // restore previous content
                myEdittext.text = myEdittext.lastKnownContent;
            } else {
                // simplify the content if necessary
                mySimplifiedTemp = myStringLigatureFormat(
                    myEdittext.text,
                    separator
                );
                if (mySimplifiedTemp !== myEdittext.text) {
                    myEdittext.text = mySimplifiedTemp;
                }
                // save this content as lastKnownContent
                myEdittext.lastKnownContent = myEdittext.text;
            }
        };
        return myEdittext;
    };

    /**
     * Asks the user what he wants to do with the given word.
     * Return an object with properties. The property returnValue
     * has a status code depending of the pressed buttons:
     *
     * 3: Do not change here
     *
     * 4: To dictionary and apply
     *
     * 5: Apply here
     *
     * any other value: The user has canceled the dialog.
     *
     * The property ligatureSetting contains the setting that
     * the user proposes.
     * @method showQuerryDialog
     * @param originalWord
     * @param instructions
     */
    namespace.showQuerryDialog = function (originalWord, instructions) {
        // variable declarations
        var myDialog,
            myReturnValue,
            myGroup,
            myTemp;

        // set up the interaction area
        myDialog = NS.extendscript.makeResizableDialog();
        myDialog.text = namespace.getLocalizedTitle();
        myDialog.contentAreaGroup = myDialog.add("group");
        myGroup = myDialog.contentAreaGroup;

        // general layout for this group
        myGroup.alignment = ["fill", "fill"];
        myGroup.orientation = "column";

        // add a panel for the word
        myTemp = myGroup.add("panel");
        myTemp.alignment = ["fill", "top"];
        myTemp.orientation = "row";
        myTemp.text = localize({en: "Word", de: "Wort"});
        myGroup.currentWord = myTemp.add('statictext {justify: "left"}');
        myGroup.currentWord.alignment = ["fill", "center"];
        myGroup.currentWord.text = NS.stringlib.replace(
            originalWord,
            "\u200C",
            separator
        );
        myGroup.firstButtonGroup = myTemp.add("group");
        myGroup.firstButtonGroup.orientation = "column";
        myGroup.firstButtonGroup.alignment = ["right", "center"];
        myGroup.ignoreButton = myGroup.firstButtonGroup.add("button");
        myGroup.ignoreButton.text = localize({
            en: "Do not modify here",
            de: "Hier nicht ver\u00E4ndern"
        });
        myGroup.ignoreButton.alignment = ["fill", "center"];
        myGroup.ignoreButton.onClick = function () {
            myDialog.close(3);
        };

        // add a panel for the ligature setting
        myTemp = myGroup.add("panel");
        myTemp.alignment = ["fill", "top"];
        myTemp.orientation = "row";
        myTemp.text = namespace.getLocalizedTitle();
        myGroup.edit = namespace.myAddLigatureEdit(
            myTemp,
            NS.liglib.getStringWithAppliedInstructions(
                originalWord,
                instructions
            ),
            separator
        );
        myGroup.edit.alignment = ["fill", "center"];
        myGroup.secondButtonGroup = myTemp.add("group");
        myGroup.secondButtonGroup.orientation = "column";
        myGroup.secondButtonGroup.alignment = ["right", "center"];
        myGroup.dictionaryAndApplyButton =
                myGroup.secondButtonGroup.add("button");
        myGroup.dictionaryAndApplyButton.text = localize({
            en: "To the dictionary and apply",
            de: "Ins W\u00F6rterbuch und anwenden"
        });
        myGroup.dictionaryAndApplyButton.onClick = function () {
            myDialog.close(4);
        };
        myGroup.dictionaryAndApplyButton.alignment = ["fill", "center"];
        myGroup.dictionaryAndApplyButton.enabled = false;
        myGroup.applyHereButton = myGroup.secondButtonGroup.add("button");
        myGroup.applyHereButton.text = localize({
            en: "Apply here",
            de: "Hier anwenden"
        });
        myGroup.applyHereButton.alignment = ["fill", "center"];
        myGroup.applyHereButton.onClick = function () {
            myDialog.close(5);
        };

        // set up a small help text
        myHelpTextString = localize(
            {
                en: "Representation of ZWJN: " + separator,
                de: "Darstellung des Bindehemmers: " + separator
            }
        );
myHelpTextWidget = myGroup.add("statictext", undefined, myHelpTextString); // gemäß scriptUI eine eigene Funktion zum Erzeugen verwenden!
        myHelpTextWidget.alignment = "left";

        // TODO sowohl StaticText als auch edittext sollten
        // auch bei extrem grossen Woertern eine bestimmte
        // minimalSize trotzdem nicht ueberschreiten!

        // set up the control area
        myDialog.controlAreaGroup = myDialog.add("group");
        mySetUpControlArea(myDialog.controlAreaGroup);
        myDialog.controlAreaGroup.nextButton.hide();

        // show
        myReturnValue =
                NS.extendscript.showWindowWithAutomaticPosition(myDialog);

        // return
        return {
            returnValue: myReturnValue,
            ligatureSetting: NS.stringlib.replace(
                myGroup.edit.text,
                separator,
                "\u200C"
            )
        };
    };

    /**
     * This function shows the start dialog.
     * @method showStartDialog
     * @param enableSelectedText
     * @return {Object} An object. It has a property "mode" of type "Number"
     * (1: no automatation, 2 only dictionary entries automatically,
     * 3 full automatation) and a property "applyToHoleDocument"  of
     * type "Boolean". So you can determine what the user has choosen in
     * the dialog.
     */
    namespace.showStartDialog = function (enableSelectedText) {
        // variable declarations
        var myTemp,
            myReturnValue = {},
            myStartDialog;

        // set up the dialog itself
        myStartDialog = NS.extendscript.makeResizableDialog(
            namespace.getLocalizedTitle()
        );

        // set up the content area
        myStartDialog.contentAreaGroup = myStartDialog.add("group");
        myStartDialog.contentAreaGroup.alignment = ["left", "fill"];
        myStartDialog.contentAreaGroup.orientation = "column";

        // "Apply to" panel
        myTemp = myStartDialog.contentAreaGroup.add("panel");
        myTemp.alignment = ["fill", "top"];
        myTemp.text = localize({en: "Apply to", de: "Anwenden auf"});
        myStartDialog.selectionRadioButton = myTemp.add("radiobutton");
        myStartDialog.selectionRadioButton.text = localize(
            {en: "\u00A0Selection", de: "\u00A0Auswahl"}
        );
        myStartDialog.selectionRadioButton.alignment = ["left", "center"];
        myStartDialog.holeDocumentRadioButton = myTemp.add("radiobutton");
        myStartDialog.holeDocumentRadioButton.text = localize({
            en: "\u00A0Hole document",
            de: "\u00A0Gesamtes Dokument"
        });
        myStartDialog.holeDocumentRadioButton.alignment = ["left", "center"];
        if (enableSelectedText) {
            myStartDialog.selectionRadioButton.value = true;
        } else {
            myStartDialog.selectionRadioButton.enabled = false;
            myStartDialog.holeDocumentRadioButton.value = true;
        }

        // "Automatation" panel
        myTemp = myStartDialog.contentAreaGroup.add("panel");
        myTemp.alignment = ["fill", "top"];
        myTemp.text = localize({en: "Automatation", de: "Automatisierung"});
        myStartDialog.manualRadioButton = myTemp.add("radiobutton");
        myStartDialog.manualRadioButton.text = localize(
            {en: "\u00A0Manual", de: "\u00A0Manuell"}
        );
        myStartDialog.manualRadioButton.alignment = ["left", "center"];
        myStartDialog.dictionaryRadioButton = myTemp.add("radiobutton");
        myStartDialog.dictionaryRadioButton.text = localize({
            en: "\u00A0Only dictionary entries automatically",
            de: "\u00A0Nur W\u00F6rterbucheintr\u00E4ge automatisch"
        });
        myStartDialog.dictionaryRadioButton.alignment = ["left", "center"];
        myStartDialog.heuristicRadioButton = myTemp.add("radiobutton");
        myStartDialog.heuristicRadioButton.text = localize({
            en: "\u00A0Everything automatically",
            de: "\u00A0Alles automatisch"
        });
        myStartDialog.heuristicRadioButton.alignment = ["left", "center"];
        myStartDialog.manualRadioButton.value = true;

        // set up the control area
        myStartDialog.controlAreaGroup = myStartDialog.add("group");
        mySetUpControlArea(myStartDialog.controlAreaGroup);
        myStartDialog.defaultElement =
                myStartDialog.controlAreaGroup.nextButton;

        // show the dialog
        myReturnValue.dialogResult =
                NS.extendscript.showWindowWithAutomaticPosition(myStartDialog);

        // determine the mode
        if (myStartDialog.heuristicRadioButton.value === true) {
            myReturnValue.mode = 3;
        } else {
            if (myStartDialog.dictionaryRadioButton.value === true) {
                myReturnValue.mode = 2;
            } else {
                myReturnValue.mode = 1;
            }
        }

        // determine the area to which we apply our operation
        myReturnValue.applyToHoleDocument =
                (myStartDialog.holeDocumentRadioButton.value === true);

        return myReturnValue;
    };

    /**
     * This function opens the HTML manual in the default program for HTML
     * files..
     * @method openManual
     */
    namespace.openManual = function () {
        var wasShown;
        wasShown = File(
            NS.extendscript.currentScriptFile().parent.fullName +
                    "/help/index.html"
        ).execute();
        if (wasShown !== true) {
            throw new Error("Could not find manual.");
        }
    };

}(NS.getNamespaceObject("ligdialog"))); // available at this namespace

// *****************************************************************************
// indesignprocessor: Adobe Indesign ligature processing library

// TODO bereits einmal behandelte Stellen beim naechsten Mal ignorieren? Falls
// kein ZWNJ gesetzt werden soll, kann einer direkt vor dem Wort gesetzt werden,
// um es zu markieren. So handhabt es Indesign auch mit bedingten Bindestrichen.

// TODO Unicode-Normalisierung: A-Umlaut würde nicht bloß als einzelnes
// Unicode-Zeichen funktionierten. Sondern A-Normal plus Trema-kombinierendes-
// Zeichen würde auch genauso funktionieren. Lohnt das wirklich?

/**
 * This module provides the processing logic for the ligature setting.
 * @class NS.indesignprocessor
 */
(function (namespace) {

    /** Helper function that applies ligature setting to a given
     * word "myTextElement" (of type Adobe text) using the
     * instructions that it will obtain from
     * myLigatureInstructions. Invalid arguments will lead
     * to a crash (except if one of the arguments is a non-value;
     * in this case, the function will return without doing
     * anything.
     * @method myApplyLigatureSetting
     * @for NS.indesignprocessor
     * @private
     * @param textElement
     * @param ligatureInstructions
     */
    function myApplyLigatureSetting(textElement, ligatureInstructions) {
        // Declare variables
        var myInstructionArray,
            i,
            myParent,
            temp;

        // return inmediatly if one of the arguments is a non-value
        if (NS.utilities.isNonvalue(textElement) ||
                NS.utilities.isNonvalue(ligatureInstructions)) {
            return;
        }

        // Return inmediatly if we do not have any characters
        // This is important, because otherwise we cannot get
        // the parent of the characters and we would trigger
        // an exception.
        if (textElement.characters.count() === 0) {
            return;
        }

        // Get the parent of the characters.
        /* We access each character by its index relative to
         * its parent. We cannot simply use
         * textElement.characters.item(x) because textElement
         * is sometimes destroyed after the execution of the
         * first instruction. So we would have a crash at the
         * execution of the second instruction. This seems to
         * happen especially when when some of the characters
         * of textElement have different properties or also
         * when the text is within a table. (We use simply the
         * first character to get the parent, and we assume that
         * there will be the same parent for all characters.
         * This seems to work. */
        myParent = textElement.characters.item(0).parent;

        // Get the appropriate ligature setting instructions array
        myInstructionArray = ligatureInstructions.instructionArray;

        // Get the index of each character relative to its parent.
        for (i = 0; i < myInstructionArray.length; i += 1) {
            myInstructionArray[i].index = textElement
                .characters
                .item(myInstructionArray[i].index)
                .index;
        }

        // Now parse our instruction list backwards.
        // If we would parse it forwards, we would change the index of the
        // instructions that still have not been applied. This would lead to
        // wrong results.
        for (i = myInstructionArray.length - 1; i >= 0; i -= 1) {
            if (myInstructionArray[i].action === 0) {
                // delete this ZERO-WIDTH NON-JOINER
                /* We test if the character that we will delete is really
                 * a ZERO-WIDTH NON-JOINER. If this program is bug-free,
                 * this will always be true. But as this program is
                 * barely bug-free, and because deleting a character
                 * is a destructive operation, we check this here again
                 * before doing any harm to the data of our user.
                 */
                temp = NS.indesign.getContentsString(
                    myParent.characters.item(myInstructionArray[i].index)
                );
                if (temp !== "\u200C") {
                    throw new Error("myApplyLigatureSetting: It was " +
                            "requested to delete a character that is not " +
                            "a ZERO-WIDTH NON-JOINER. This is always a " +
                            "programming error!");
                }
                // actually delete this character
                myParent
                    .characters
                    .item(myInstructionArray[i].index)
                    .contents = "";
            } else {
                // insert a ZERO WIDTH NON-JOINER \u200C after
                // this character
                myParent
                    .characters
                    .item(myInstructionArray[i].index)
                    .insertionPoints
                    .lastItem()
                    .contents = "\u200C";
            }
        }
    }

    /**
     * Creates an adobeTextProcessingObject.
     * @method makeAdobeTextProcessing
     * @for NS.indesignprocessor
     * @param myTexts {Object or Array} is either an Adobe text
     * object or an array of Adobe text objects
     * @param myDeepth {String} "deep" if you want to iteraterate also through
     * child tables and child footnotes. Otherwise "flat".
     * @param mode {Number} 1 for manual ligature setting, 2 for only dictionary
     * entries automatically, 3 for fully automatically.
     * @return {Object} Returns an adobeTextProcessing object.
     */
    namespace.makeAdobeTextProcessing = function (
        myTexts,
        myDeepth,
        myMode
    ) {
        /**
         * adobeTextProcessingObject helps to do the ligature setting.
         * @class adobeTextProcessing
         */
        var mode = myMode,
            ligatureProcessing,
            myReturnValue,
            temp,
            currentLigatureInstructions,
            userInteractionRequiered,
            internalRequieresUserInteraction,
            myWordDictionary,
            myCurrentWord,
            myWordIndex = NS.indesign.makeWordIterator(myTexts, myDeepth),
            myWordCountIndicator,
            myWordCount;

        myWordDictionary = NS.indict.makeDictionaryObject(
            String(NS.extendscript.currentScriptFile().parent.fullName) +
                    "/liglist.UTF16LE.txt"
        );

        // initialize ligatureProcessing
        ligatureProcessing = NS.liglib.makeLigatureProcessor(
            undefined, // TODO currently no user dictionary used
            myWordDictionary.search
        );

        // initialize word count indicator
        myWordCount = 0;
        myWordCountIndicator = new Window("palette");
        myWordCountIndicator.text = NS.ligdialog.getLocalizedTitle();
        // "justify" must be initialized by this
        // command string ("resource string"). Otherwise it would not work
        // reliable on Windows.
        myWordCountIndicator.myLabel = myWordCountIndicator.add(
            'statictext {alignment: "fill", justify: "center"}'
        );
        myWordCountIndicator.add(
            "statictext",
            undefined,
            localize({
                en: "For cancel press ESC key.",
                de: "F\u00FCr Abbruch ESC-Taste dr\u00FCcken."
            })
        );

        myReturnValue = {};

        /**
         * @method getCurrentWordString
         * @return {String or Undefined} A string with the content of the
         * current word. If there is a current word, than its content is
         * returned as a string. If we have reached the end, than the return
         * value is undefined.
         */
        myReturnValue.getCurrentWordString = function () {
            if (NS.utilities.isNonvalue(myCurrentWord)) {
                return undefined;
            }
            return NS.indesign.getContentsString(myCurrentWord);
        };

        myReturnValue.getCurrentLigatureInstructions = function () {
            // TODO Return a copy instead of the original
            return currentLigatureInstructions;
        };

        myReturnValue.apply = function (instructions) {
            // TODO Check if the instructions are correct
            myApplyLigatureSetting(
                myCurrentWord,
                instructions
            );
        };

        /**
         * Move the current index position to the next word.
         * @method advance
         */
        myReturnValue.advance = function () {
            // switch to the next word
            myCurrentWord = myWordIndex.getNextWord();
            /*
            //for debugging purpose
            if (NS.utilities.isNonvalue(myCurrentWord)) {
                $.writeln("next word is undefined");
            } else {
                $.writeln("next word: " +
                        NS.indesign.getContentsString(myCurrentWord));
            }
            */
        };

        // go to the first word now
        myReturnValue.advance();

        /**
         * @method internalRequieresUserInteraction
         * @private
         * @return wether a ligature setting with the given statusCode
         * requieres a user interaction (following the mode that was
         * given when calling the factory). */
        internalRequieresUserInteraction = function (
            statusCode
        ) {
            return (statusCode > mode);
        };

        /**
         * @method getUserInteractionRequiered
         * @return {Boolean} true if at the current index position in the text
         * there is a user interaction required (for example because a word
         * was not found in the dictionary, but the user operates in the mode
         * "only dictionary entries automatically"). Otherwise false.
         */
        myReturnValue.getUserInteractionRequiered = function () {
            return Boolean(userInteractionRequiered);
        };

        /**
         * Starting with the current index, this function goes
         * through the text. While if finds words that are ignored
         * or words that are corrected automatically (following
         * the mode that was specified in the factory call)
         * it applies this correction. But if it finds a word
         * that requieres a user interaction or if it reaches
         * the end of the text, it will return. After this
         * function has returned, you can use
         * getUserInteractionRequiered() to know about the status.
         * @method continue
         */
        myReturnValue.continue = function () {
            // initialize
            userInteractionRequiered = false;

            // display the progress indicator
            // (except when in "manual" mode, because than it is not worth
            // the pain.
            if (mode !== 1) {
                NS.extendscript.showWindowWithAutomaticPosition(
                    myWordCountIndicator
                );
            }

            // enter in the processing loop
            while (!NS.utilities.isNonvalue(myCurrentWord) &&
                    !userInteractionRequiered) {
                myWordCount += 1;
                myWordCountIndicator.myLabel.text =
                        myWordCount.toString() + " \u2026"; // " ..."
                // If the word is not german, we skip it.
                if (NS.indesign.myIsGerman(myCurrentWord.appliedLanguage)) {
                    // Get the appropriate ligature setting instructions
                    currentLigatureInstructions = ligatureProcessing
                        .getWordInstructions(myReturnValue
                            .getCurrentWordString());
                    // Test if we can do our change without a user interaction
                    temp = internalRequieresUserInteraction(
                        currentLigatureInstructions.statusCode
                    );
                    if (!temp) {
                        myApplyLigatureSetting(
                            myCurrentWord,
                            currentLigatureInstructions
                        );
                        myReturnValue.advance();
                    } else {
                        userInteractionRequiered = true;
                        NS.indesign.exposeText(myCurrentWord);
                    }
                } else {
                    myReturnValue.advance();
                }
            }

            myWordCountIndicator.hide();
        };

        return myReturnValue;
    };
}(NS.getNamespaceObject("indesignprocessor"))); // available at this namespace

// *****************************************************************************
// Dictionary generator library: dictgenerator

/**
 * This statement makes some dictionary generator functions available.
 * It requires Node.js.
 * @class NS.dictgenerator
 */
(function (namespace) {

    /**
     * @method simplifyWordlistLine
     * @param wordlistLine {Object} A buffer as delivered by n-readlines. It
     * is assumed to contain a line of the word list from the Trennmuster
     * project.
     * @return {String or Undefined} A simplified version of the line, that
     * contains simply the word with ZWNJ characters at the appropriate
     * places. If the line is invalid or if it contains a word with multiple
     * alternative meanings and hyphenation points, than this function returns
     * Undefined.
     */
    function simplifyWordlistLine(wordlistLine) {
        // variable declarations
        var myString,
            temp,
            myArray,
            i;

        // wordlistLine contains the current line without the trailing newline
        // character(s), but it is a buffer object. We convert it to a
        // string.
        myString = wordlistLine.toString('utf8');

        // remove comments
        temp = myString.indexOf("#");
        if (temp >= 0) {
            myString = myString.slice(0, temp);
        }

        // test for double meaning
        if (myString.indexOf("[") >= 0) {
            return undefined;
        }

        // remove whitespace
        myString = myString.trim();

        // remove information about special hyphenation following 1901
        // ortohography (Not usefull because Indesign makes the hyphenation
        // automatically, but scripts access normally to the
        // non-hyphenated underlying data.)
        // We use *? instead of *, because * is greedy,
        // but *? is reluctant/non-greedy, which makes sure that we do not
        // match various blocks at the same time.
        myString = myString.replace(/(\{)(.*?)\/.*?\}/g, "$2");

        // remove hyphenations within morphems (not usefull for
        // ligature setting)
        myString = NS.stringlib.replace(myString, "-", "");

        // remove hyphenations disqualifiers (not usefull for ligature setting)
        myString = NS.stringlib.replace(myString, ".", "");

        // use "#" as sign for morphem boundries ("<", ">", "=")
        // ("#" is guaranteed to not occure in the string, because it is
        // the sign for comments, and comments are yet filtered out)
        myString = NS.stringlib.replace(myString, "<", "#");
        myString = NS.stringlib.replace(myString, ">", "#");
        myString = NS.stringlib.replace(myString, "=", "#");

        // remove duplicate morphem boundaries
        while (myString.indexOf("##") >= 0) {
            myString = NS.stringlib.replace(myString, "##", "#");
        }

        // switch from # to ZWNJ
        myString = NS.stringlib.replace(myString, "#", "\u200C");

        // transform into an array
        myArray = [undefined];
        myArray = myArray.concat(myString.split(";"));
        for (i = 0; i < myArray.length; i += 1) {
            // search for empty field (like "-2-", but dashes are yet
            // removed) or for unclassified hyphenation points ("\u00B7")
            // and replace them by undefined
            if (/^[2-8]$/.test(myArray[i]) ||
                    (myString.indexOf("\u00B7") >= 0)) {
                myArray[i] = undefined;
            }
        }

        // load the first non-empty hyphenation rule into "temp" (rules start
        // at field 2)
        i = 2;
        temp = undefined;
        while (i <= 8) {
            if (NS.utilities.isNonvalue(myArray[i])) {
                i += 1;
            } else {
                temp = myArray[i];
                break;
            }
        }

        // Test if all other rules have the same content. If not, make
        // "temp" undefined
        i += 1;
        while (i <= 8 && !NS.utilities.isNonvalue(temp)) {
            if (!NS.utilities.isNonvalue(myArray[i])) {
                if (myArray[i] !== temp) {
                    console.log("Ignoring (invalid entry): " + myArray);
                    temp = undefined;
                }
            }
            i += 1;
        }

        // return
        return temp;
    }

    function sortDictionary(dictionaryFilePath, outputFilePath) {
        // variable declarations
        var valueAt,
            isFirstSmallerThanSecond,
            lastIndex,
            blockSize = 200,
            myInputFileHandle,
            myOutputFileHandle,
            mySortFunction,
            fs = require("fs"),
            myArray,
            i;

        // internal functions
        /* Returns the block at index as Buffer. */
        valueAt = function (index) {
            var myReturnValue = new Buffer(blockSize);
            fs.readSync(
                myInputFileHandle,
                myReturnValue,
                0,
                blockSize,
                index * blockSize
            );
            return myReturnValue;
        };
        isFirstSmallerThanSecond = function (first, second) {
            return first.toString("utf16le") < second.toString("utf16le");
            //return Boolean(Buffer.compare(first, second) < 0);
        };
        lastIndex = function () {
            return (fs.fstatSync(myInputFileHandle).size / blockSize) - 1;
        };

        // get the sort order of the dictionary
        console.log(new Date());
        console.log("Get the sort order of the dictionary ...");
        // get read access
        myInputFileHandle = fs.openSync(dictionaryFilePath, "r");
        mySortFunction = NS.algorithms.makeIndirectIterativeQuicksortFunction(
            valueAt,
            isFirstSmallerThanSecond,
            lastIndex
        );
        myArray = mySortFunction();

        // apply the sort order while writing to disk
        console.log(new Date());
        console.log("Apply sorting to dictionary while writing to disk ...");
        myOutputFileHandle = fs.openSync(outputFilePath, "w");
        for (i = 0; i < myArray.length; i += 1) {
            fs.appendFileSync(outputFilePath, valueAt(myArray[i]));
        }

        // close open file handles
        fs.closeSync(myOutputFileHandle); // close file
        fs.closeSync(myInputFileHandle); // close file
    }

    /**
     * @method makeEntryString
     * @private
     * @param word {String or Undefined}
     * @return {String or Undefined} A string with a key-value-pair, ready
     * for writing in the dictionary file. If the string could not be
     * produced because it exceeds the field length of the dictionary,
     * or if the word paramater was undefined, it returns undefined.
     */
    function makeEntryString(word) {
        // The maximal length is the length of the field less 2, because
        // CR + LF take the space of 2 codeunits.
        var maxLength = NS.indict.getFieldCodeunitLength - 2,
            myKeyValuePair;
        if (!NS.utilities.isNonvalue(word)) {
            myKeyValuePair = NS.liglib.makeEntry(word);
            if (myKeyValuePair[0].length > maxLength) {
                console.log("Ignoring (too long): " + myKeyValuePair);
            } else {
                while (myKeyValuePair[0].length < maxLength) {
                    myKeyValuePair[0] += " ";
                }
                myKeyValuePair[0] += "\u000D\u000A";
                while (myKeyValuePair[1].length < maxLength) {
                    myKeyValuePair[1] += " ";
                }
                myKeyValuePair[1] += "\u000D\u000A";
                return (myKeyValuePair[0] + myKeyValuePair[1]);
            }
        }

        // fallback
        return undefined;
    }

    /**
     * Process the wordlist of the Trennmuster project.
     * @method transformToDictionary
     * @private
     * @param inputFile {String} The path to the existing wordlist from
     * the Trennmuster project.
     * @param indesignDictionaryFile {String} The path where a ligature
     * dictionary for our Indesign script will be created.
     * (UTF16LE without BOM)
     * @param indesignDictionaryFile {String} The path where a ligature
     * dictionary for input for patgen will be created.
     * (UTF8 without BOM)
     */
    function transformToDictionary(
        inputFile,
        indesignDictionaryFile,
        patgenDictionaryFile
    ) {
        // variable declarations
        var fs,
            LineByLine,
            indesignDictionaryFileHandle,
            patgenDictionaryFileHandle,
            liner,
            line,
            mySimplifiedLine,
            myEntryString;

        // load en extension: fs
        fs = require("fs");

        // load an extension: n-readlines
        // TODO DANGER This does not work as expected with all possibilities
        // for CRLF, CR, LF (at least with UFT8 I had bugs...)
        LineByLine = require('n-readlines');

        // prepare the output files with write-only access "w"
        indesignDictionaryFileHandle = fs.openSync(indesignDictionaryFile, "w");
        patgenDictionaryFileHandle = fs.openSync(patgenDictionaryFile, "w");

        // process data from the input file
        liner = new LineByLine(inputFile);
        line = liner.next();
        while (line !== false) {
            mySimplifiedLine = simplifyWordlistLine(line);
            myEntryString = makeEntryString(mySimplifiedLine);
            if (!NS.utilities.isNonvalue(myEntryString)) {
                fs.appendFileSync(
                    indesignDictionaryFile,
                    myEntryString,
                    {encoding: "utf16le"}
                );
                fs.appendFileSync(
                    patgenDictionaryFile,
                    // Replace ZWNJ character \u200C with HYPHEN-MINUS character
                    NS.stringlib.replace(
                        // unify (lower-case etc.) and add line-break:
                        NS.liglib.unify(mySimplifiedLine) + "\u000D\u000A",
                        "\u200C",
                        "-"
                    ),
                    {encoding: "utf8"}
                );
            }
            line = liner.next();
        }

        // close the output file
        fs.closeSync(indesignDictionaryFileHandle);
        fs.closeSync(patgenDictionaryFileHandle);
    }

    /**
     * Takes a word list from the Trennmuster project and makes a dictionaries
     * from it. Requires Node.js. May take about 30 minutes.
     * @method makeDictionary
     * @param inputFilePath {String} The path to the Trennmust word list.
     * @param tempFilePath {String} The path for a temporary
     * file. If the file does not exist, it will be created. If it does exist,
     * it will be overwritten.
     * @param outputFilePath {String} The path for the output file.
     * If the file does not exist, it will be created. If it does exist,
     * it will be overwritten. It will contain a UTF16LE (without BOM)
     * encoded ligature dictionary for use with our Indesign script.
     * @param output2FilePath {String} The path for the output file 2.
     * If the file does not exist, it will be created. If it does exist,
     * it will be overwritten. It will contain a UTF8 (without BOM)
     * encoded ligature dictionary for use with patgen. Note that you mind
     * want to convert it to some 8-bit encoding before giving it to patgen.
     */
    namespace.makeDictionary = function (
        inputFilePath,
        tempFilePath,
        outputFilePath,
        output2FilePath
    ) {
        // make the dictionary
        console.log(new Date());
        console.log("Transform to dictionary ...");
        transformToDictionary(inputFilePath, tempFilePath, output2FilePath);

        // sort the dictionary
        sortDictionary(tempFilePath, outputFilePath);

        // terminate
        console.log(new Date());
        console.log("Finished.");
    };
}(NS.getNamespaceObject("dictgenerator"))); // available at this namespace

// *****************************************************************************
// Unicode Character Database Regular Expressions

/**
 * This statement makes some dictionary generator functions available.
 * It requires Node.js.
 * @class NS.ucsregexp
 */
(function (namespace) {

    function processLine(line, database) {
        var myLine,
            myData,
            myRange,
            myRangeStart,
            myRangeEnd,
            myCategory,
            temp,
            startNumber,
            endNumber,
            i,
            high,
            low,
            mySurrogatePairs;

        // "#" starts a comment. We use only the part before "#" character and
        // discard the rest.
        myLine = line.toString('utf8').split("#")[0];
        if (NS.utilities.isNonvalue(myLine) || myLine === "") {
            return;
        }
        // And the part before "#" is split in two parts
        // again (before and after the ";").
        myData = myLine.split(";");
        myRange = myData[0].trim().split("..");
        myRangeStart = myRange[0];
        myRangeEnd = myRange[1];
        myCategory = myData[1];
        if (NS.utilities.isString(myCategory)) {
            myCategory = myCategory.trim();
        }

        // Return if there is no data in this line
        if (NS.utilities.isNonvalue(myRangeStart) || myRangeStart === "") {
            return;
        }

        // Process the data
        if (!NS.utilities.isObject(database[myCategory])) {
            database[myCategory] = {
                bmpElements: [],
                surrogatePairs: []
            };
        }

        if (myRangeStart.length === 4) {
            database[myCategory].bmpElements.push("\u005Cu" + myRangeStart);
            if (!NS.utilities.isNonvalue(myRangeEnd)) {
                database[myCategory].bmpElements.push("-");
                database[myCategory].bmpElements.push("\u005Cu" + myRangeEnd);
            }
        } else { // myRangeStart.length === 5
            if (NS.utilities.isNonvalue(myRangeEnd) || myRangeEnd === "") {
                myRangeEnd = myRangeStart;
            }
            startNumber = parseInt(myRangeStart, 16);
            endNumber = parseInt(myRangeEnd, 16);
            for (i = startNumber; i <= endNumber; i += 1) {
                temp = NS.stringlib.fromScalarValue(i);
                high = temp.charCodeAt(0);
                low = temp.charCodeAt(1);
                mySurrogatePairs = database[myCategory].surrogatePairs;
                if (!NS.utilities.isArrayObject(mySurrogatePairs[high])) {
                    mySurrogatePairs[high] = [];
                }
                mySurrogatePairs[high].push(low);
            }
        }
    }

    function makeRegExp(myElement) {
        myElement.regexp = [];
        myElement.regexp.push("("); // Initial parenthesis
        if (myElement.bmpElements.length > 0) {
            myElement.regexp = myElement.regexp.concat(
                "[",
                myElement.bmpElements,
                "]"
            );
        }
        myElement.surrogatePairs.forEach(function (element, index) {
            myElement.regexp = myElement.regexp.concat(
                "|",
                NS.stringlib.formatAsUnicodeEscape(index),
                "[",
                element,
                "]"
            );
        });
        myElement.regexp.push(")"); // Final parenthesis
        // If there are no BMP codepoints, than the string starts with
        // "(|", which would match an empty string, what is wrong.
        // So we have to remove it.
        if (myElement.regexp[1] === "|") {
            myElement.regexp[1] = "";
        }
        // Unify upper/lower case: convert to upper case except "u"
        myElement.regexp.forEach(function (element, index, array) {
            array[index] = NS.stringlib.replace(
                element.toUpperCase(),
                "U",
                "u"
            );
        });
    }

    function makeHighSurrogateRanges(myArray, myIndex, myParentArray) {
        var myNewArray = [],
            i,
            j;

        i = 0;
        while (i < myArray.length) {
            // search end of range
            j = i;
            while (myArray[j + 1] === myArray[j] + 1) {
                j += 1;
            }
            myNewArray.push(NS.stringlib.formatAsUnicodeEscape(myArray[i]));
            if (i !== j) {
                myNewArray.push("-");
                myNewArray.push(NS.stringlib.formatAsUnicodeEscape(myArray[j]));
            }
            i = j + 1;
        }
        myParentArray[myIndex] = myNewArray;
    }

    function formatRegExp(myRegExp, myLeadSpace, myLineLength) {
        var myReturnValue = "",
            i,
            max = myLineLength - 3, // 3 characters (trailing "\" +")
            myLine;
        /* A Unicode escape sequence takes 6 characters: \u1234
         */
        if (max < (myLeadSpace + 6)) {
            throw new Error("Invalid arguments.");
        }
        i = 0;
        while (i < myRegExp.length) {
            myLine = myLeadSpace + "\"";
            while ((i < myRegExp.length) &&
                    ((myLine.length + myRegExp[i].length) <= max)) {
                myLine += myRegExp[i];
                i += 1;
            }
            myReturnValue += myLine;
            // only append a plus sign if this is not the last line
            if (i < myRegExp.length) {
                myReturnValue += "\" +\n";
            } else {
                myReturnValue += "\"\n";
            }
        }
        return myReturnValue;
    }

    namespace.processFile = function (inputFile, outputFile) {
        // variable declarations
        var fs,
            data,
            outputFileHandle,
            database = {},
            i,
            myCategories;

        // load en extension: fs
        fs = require("fs");

        // load data
        data = fs.readFileSync(inputFile, {encoding: "utf8"})
            .split(/[\u000D\u000A]/);

        // process data from the input file line by line
        for (i = 0; i < data.length; i += 1) {
            processLine(data[i], database);
        }

        // Make ranges
        myCategories = Object.keys(database);
        for (i = 0; i < myCategories.length; i += 1) {
            database[myCategories[i]].surrogatePairs.forEach(
                makeHighSurrogateRanges
            );
        }
        // Make RegExp
        for (i = 0; i < myCategories.length; i += 1) {
            makeRegExp(database[myCategories[i]]);
        }

        // prepare the output file
        outputFileHandle = fs.openSync(outputFile, "w"); // write-only access
        for (i = 0; i < myCategories.length; i += 1) {
            fs.writeSync(
                outputFileHandle,
                myCategories[i] +
                        "\n" +
                        formatRegExp(database[myCategories[i]].regexp,
                        "            ", 80) +
                        "\n\n",
                undefined,
                {encoding: "utf8"}
            );
        }
        // close the output file
        fs.closeSync(outputFileHandle);
    };

}(NS.getNamespaceObject("ucdregexp"))); // available at this namespace

// *****************************************************************************
// sourceformat: Helper library to format ECMAScript source code

/**
 * This statement provides a helper library that helps to format
 * ECMAScript source code.
 * @class NS.sourceformat
 */
(function (namespace) {

    /**
     * @method formatString
     * @param firstLineLength {Number} The length of the first line
     * @param furtherLineLength {Number} The length of all other lines,
     * starting from the second one.
     * @param indent {String} A string with the indent characters (usually
     * spaces or tabulators) for all lines except the first one.
     * @param myText {String} The text that will be formated
     * @return {String} The formated text.
     */
    namespace.formatString = function (
        firstLineLength,
        furtherLineLength,
        indent,
        myText
    ) {
        var allowedCharacters = /[a-zA-Z_0-9]/,
            currentLineMaxLength = firstLineLength,
            i = 0,
            nextCharacter,
            lines = [];

        lines.push("\"");
        while (i < myText.length) {
            nextCharacter = myText.charAt(i);
            // If the character is not one of the allowed ones, we replace
            // it with a unicode escape sequenze
            if (!allowedCharacters.test(nextCharacter)) {
                nextCharacter = NS.stringlib.formatAsUnicodeEscape(
                    nextCharacter.charCodeAt(0)
                );
            }
            if (lines[lines.length - 1].length + nextCharacter.length + 3 >
                    currentLineMaxLength) {
                lines[lines.length - 1] += "\" +";
                lines.push(indent + "\"");
                currentLineMaxLength = furtherLineLength;
            }
            lines[lines.length - 1] += nextCharacter;
            i += 1;
        }
        lines[lines.length - 1] += "\"";
        return lines.join("\n");
    };

    /**
     * Processes the input file line by line and makes ECMAScript source
     * code strings of it and writes them to the output file.
     * @method formatTextFileContentAsStrings
     * @param inputFile {String} The path to an UTF8-encoded input file
     * @param outputFile {String} The path where the UTF8-encoded output file
     * will be written.
     */
    namespace.formatTextFileContentAsStrings = function (
        inputFile,
        outputFile
    ) {
        // variable declarations
        var fs,
            data,
            outputFileHandle,
            i;

        // load en extension: fs
        fs = require("fs");

        // load data
        data = fs.readFileSync(inputFile, {encoding: "utf8"})
            .split(/[\u000D\u000A]/);

        // prepare the output file
        outputFileHandle = fs.openSync(outputFile, "w"); // write-only access

        // process data from the input file line by line
        for (i = 0; i < data.length; i += 1) {
            fs.writeSync(
                outputFileHandle,
                namespace.formatString(50, 80, "        ", data[i]) + "\n\n",
                undefined,
                {encoding: "utf8"}
            );
        }

        // close the output file
        fs.closeSync(outputFileHandle);
    };

}(NS.getNamespaceObject("sourceformat"))); // available at this namespace

// *****************************************************************************
// inligaturesetting: Adobe Ligature setting system

/**
 * This statement provides the Ligature setting for Indesign for the user.
 * @class NS.inligaturesetting
 */
(function (namespace) {

    /**
     * This function performces the ligature setting with the options
     * that the user has choosen.
     * @method doLigatureSetting
     * @private
     * @param mySelectedText {Array or Undefined} If an array of Text Objects,
     * than the ligature setting is done for this content. If undefined, the
     * ligature setting is done for the hole document.
     * @param mode
     * @return {Nothing}
     */
    function doLigatureSetting(mySelectedText, mode) {
        // declare variables
        var myUserAbort,
            showQuerryDialogResult,
            myAdobeTextProcessing,
            i,
            temp;

        // initialize our InDesign ligature processing object
        // determine the text that will be concerned
        if (NS.utilities.isNonvalue(mySelectedText)) {
            temp = [];
            for (i = 0; i < app.activeDocument.stories.length; i += 1) {
                temp.push(app.activeDocument.stories[i]);
            }
            // TODO Order the stories according to their appearance within
            // the document.
            myAdobeTextProcessing = NS.indesignprocessor
                .makeAdobeTextProcessing(temp, "deep", mode);
        } else {
            myAdobeTextProcessing = NS.indesignprocessor
                .makeAdobeTextProcessing(mySelectedText, "flat", mode);
        }

        // process the text
        myUserAbort = false;
        while (!NS.utilities.isNonvalue(myAdobeTextProcessing
            .getCurrentWordString()) && !myUserAbort) {
            myAdobeTextProcessing.continue();
            if (myAdobeTextProcessing.getUserInteractionRequiered()) {
                showQuerryDialogResult = NS.ligdialog.showQuerryDialog(
                    myAdobeTextProcessing.getCurrentWordString(),
                    myAdobeTextProcessing.getCurrentLigatureInstructions()
                );
                switch (showQuerryDialogResult.returnValue) {
                case 3: // ignore
                    myAdobeTextProcessing.advance();
                    break;
                case 4: // toDictionaryAndApply
                // WARNING eventuell vorhandene Eintraege
                // ueberschreiben! Scharfes-s-normales-s-sicher!
                    // TODO implement me!
                    throw new Error("This function is still not implemented.");
                case 5: // applyHere
                    myAdobeTextProcessing.apply(
                        NS.liglib.makeIndividualWordInstruction(
                            myAdobeTextProcessing.getCurrentWordString(),
                            NS.liglib.makeEntry(
                                showQuerryDialogResult.ligatureSetting
                            )[1]
                        )
                    );
                    myAdobeTextProcessing.advance();
                    break;
                default: // abort
                    myUserAbort = true;
                    break;
                }
            }
            // TODO use update() to get the progress bar correctly displayed
            // TODO use characters property for aligning SCRIPTUI elements!
        }

        if (!myUserAbort) {
            NS.extendscript.showWindowWithAutomaticPosition(
                NS.extendscript.myDisplayMessageDialog(
                    localize({
                        en: "Ligature setting is finished.",
                        de: "Der Ligatursatz ist abgeschlossen."
                    }),
                    NS.ligdialog.getLocalizedTitle()
                )
            );
        }

        // clear the selection
        app.select(NothingEnum.nothing);
    }

    /**
     * Shows the user interface for ligature setting and performes the actions
     * that the user choose.
     * @method callLigatureSetting
     * @return {None}
     */
    namespace.callLigatureSetting = function () {
        // declare variables
        var myTemp,
            mySelectedText;

        // Display warning because this is still beta software
        NS.extendscript.myDisplayMessageDialog(
            localize({
                en: "The ligature setting is still under development " +
                        "(beta software). Be carefull!",
                de: "Der Ligatursatz befindet sich noch in der " +
                        "Entwicklung (Beta-Software). Seien Sie vorsichtig!"
            }),
            NS.ligdialog.getLocalizedTitle(),
            localize({
                en: "OK",
                de: "OK"
            })
        ).show();

        // Test if there is a document
        if (app.documents.count() === 0) {
            NS.extendscript.myDisplayMessageDialog(
                localize({
                    en: "Ligature setting in only available while " +
                            "a document is open.",
                    de: "Der Ligatursatz steht nur zur Verf\u00FCgung, " +
                            "w\u00E4hrend ein Dokument ge\u00F6ffnet ist."
                }),
                NS.ligdialog.getLocalizedTitle()
            ).show();
            // We have to stop here. (Many parts of the Adobe script objects
            // would crash if used without that a document is open.)
            return;
        }

        // Get the current selection
        mySelectedText = NS.indesign.getCurrentTextSelection();

        // Call the start dialog
        myTemp = NS.ligdialog.showStartDialog(mySelectedText.length > 0);

        // Stop here if the user has canceled the operation in the start dialog
        if (myTemp.dialogResult !== 1) {
            return;
        }

        // start the actual ligature setting process
        if (myTemp.applyToHoleDocument) {
            doLigatureSetting(undefined, myTemp.mode);
        } else {
            doLigatureSetting(mySelectedText, myTemp.mode);
        }
    };

}(NS.getNamespaceObject("inligaturesetting"))); // available at this namespace

// *****************************************************************************

// TODO Wenn soft hyphen im Text auftauchen, dann waere es sinnvoll, diese auch
// im Ligaturdialog zu ignorieren (wie sie von unseren Regeln ja auch ignoriert
// werden.) Testen!

/*
  TODO
    Was, wenn
    ein Wort ignoriert wird, aber trotzdem
    einen Bindehemmer hat??? Beispiel:
    Das Wort „oft“ mit einem Bindehemmer
    zwischen f und t wird ignoriert. Es sollte
    aber vielleicht besser korrigiert werden,
    oder? Sollte dann
    trotzdem angezeigt werden, damit dieser
    Bindehemmer entfernt werden kann!!
*/